<?php include "config.php";
?>
<?php include"header.php";

?>
	<?php 
	if(isset($_POST['savechange'])){
	$opass=md5($_POST['oldpassword']);
$npass=mysql_real_escape_string($_POST['npassword']);
$cpass=mysql_real_escape_string($_POST['cpassword']);
			
$sql=mysql_query("select password from employeer where user_email='$_SESSION[user]'");
if($row=mysql_fetch_array($sql))
{ 
$old=$row['password'];
	if($opass==$old)
	{
		if($npass==$cpass)
		{
		$sql=mysql_query("update employeer set password=md5('$npass') where user_email='$_SESSION[user]'");
	   $msge = 'Password Changes successfully';
	   }
		else{
			$msge = "Password are not Same";
}
	}
		else
		{
			$msge = "Old Password is not Correct";
		}
		
		}
		
}

?>	
		<div class="main-page-title">
					<div class="container">
				<div class="post-job-title">Your Previous Posted Job</div>
				<div class="post-job-phone">Any Query Call Us : 0141 - 3356493</div>
			</div>
		</div>
		<div class="container">
		<div class="spacer-1">&nbsp;</div>
			<div class="row"  style="min-height:300px;">
	<div class='col-md-9' >
	<?php 
				if(isset($_POST['savechange']))
				{
					echo "<p style='color: #fff;
    text-align: center;
    padding: 5px;
    background: #F75900;
    border-radius: 9px;'>$msge</p>";
    echo"<div class='clearfix'></div>";
				}
				?>
<p align="center" style="font-size:20px;">Employeer Change Password</p><hr><br>
		<form action="#" method="post" >
<label style="width:30%;">Old password</label><input type="password" name="oldpassword" class="pop_login" required >

<label style="width:30%;">New Password </label><input type="password" name="npassword" class="pop_login" required>

<label style="width:30%;">Confirm Password </label><input type="password" name="cpassword" class="pop_login" required>

<input type="submit"  value="SAVE" name="savechange" class="changepass">
	
</form>


	</div>			
	<div class="col-md-3">
					

					

					<div class="job-side-wrap" >
						
					<p align="center" style="width:100%; height:36px;background:#F75900;border-radius:3px;border:none;color:#fff;font-size:20px">
						Administration
					<div class="admin"><li><a href="editprofile.php">Edit Profile</a></li>
					  <li><a href="changepass.php">Change Password</a></li>
					  <li><a href="index.php">My Posted Jobs</a></li>
					  <li><a href="help.php">Help</a></li>
					  <li><a href="logout.php">Logout</a></li>
					
					</div>
					</div>
				</div>
			</div>
		</div>

	
<?php
include"footer.php";
?>