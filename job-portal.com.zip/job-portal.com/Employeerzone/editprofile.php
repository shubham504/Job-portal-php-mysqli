<?php
session_start();
include"header.php";
include"config.php";

if(isset($_POST['register']))
{
	
	$mail=$_POST['mail'];
	
	
	$name=$_POST['company'];
	
	$phone=$_POST['contact'];
	
	$add=$_POST['address'];
	$city=$_POST['city'];
	
	$state=$_POST['state'];
	
	$zip=$_POST['zip'];
	$sql=mysql_query("update employeer set company='$name',contact='$phone',address='$add',city='$city',state='$state',zip='$zip' where user_email='$_SESSION[user]'"); 
	$msg1="Your Profile Updated Successfully";
	}
?>
				<div class="main-page-title"><!-- start main page title -->
		<div class="container">
				<div class="post-job-title">Your Previous Posted Job</div>
				<div class="post-job-phone">Any Query Call Us : 0141 - 3356493</div>
			</div>
		</div>
		<div class="container">
			
		<div class="spacer-1">&nbsp;</div>
			<div class="row">
				<div class="col-md-9">
				
					<p style="color:red"><?php
					if(isset($_POST['register']))
					{
						echo $msg1;
					}
					?></p>
					<form role="form" class="post-job-form" method="post" action="">
					<?php
					
					$sql=mysql_query("select * from employeer where user_email='$_SESSION[user]'");
                    if($row=mysql_fetch_array($sql))
					{	
					?>
						<div class="form-group">
							<label for="email">Your Email</label>
					<input type="text" class="form-control input" id="email" name="mail" value="<?php echo $row['user_email']?>" readonly/>
						</div>

						<div class="form-group">
							<label for="joblocation">Company Name </label>
							<input type="text" class="form-control input" id="joblocation" value="<?php echo $row['company']?>" name="company" required />
							
						</div>


						
					<div class="form-group">
							<label for="appemail">Contact No </label>
							<input type="text" class="form-control input" id="appemail" value="<?php echo $row['contact']?>" name="contact" required/>
						</div>


						
							<div class="form-group">
								<label for="companyname">Address</label>
								<input type="text" class="form-control input" id="companyname" value="<?php echo $row['address']?>" name="address" required />
							</div>

							<div class="form-group">
								<label for="tagline">City</label>
								<input type="text" class="form-control input" value="<?php echo $row['city']?>" id="tagline" name="city" />
							</div>
						
							<div class="form-group">
								<label for="tagline">State</label>
								<select name="state" class="form-control input" value="<?php echo $row['state']?>"><option><?php echo $row['state']?></option>
								<option value="Andhra Pradesh"> Andhra Pradesh </option>
								<option value="Arunachal Pradesh"> Arunachal Pradesh</option>
								<option value="Assam">Assam</option>
								<option value="Bihar"> Bihar</option>
								<option value="Chhattisgarh"> Chhattisgarh</option>
								<option value="Goa"> Goa</option>
								<option value="Gujarat"> Gujarat</option>
								<option value="Haryana"> Haryana</option>
								<option value="Himachal Pradesh"> Himachal Pradesh</option>
								<option value="Jammu & Kashmir"> Jammu & Kashmir</option>
								<option value="Jharkhand">Jharkhand</option>
								<option value="Karnataka"> Karnataka</option>
								<option value="Kerala"> Kerala</option>
								<option value="Madhya Pradesh"> Madhya Pradesh</option>
								<option value="Maharashtra"> Maharashtra</option>
								<option value="Manipur"> Manipur</option>
								<option value="Meghalaya"> Meghalaya</option>
								<option value="Mizoram"> Mizoram</option>
								<option value="Nagaland"> Nagaland</option>
								<option value="Odisha "> Odisha </option>
								<option value="Punjab"> Punjab</option>
								<option value="Rajasthan"> Rajasthan</option>
								<option value="Sikkim"> Sikkim</option>
								<option value="Tamil Nadu"> Tamil Nadu</option>
								<option value="Telangana"> Telangana</option>
								<option value="Tripura">Tripura</option>
								<option value="Uttar Pradesh">Uttar Pradesh</option>
								<option value="Uttarakhand">Uttarakhand</option>
								
								</select>
								</div>
							<div class="form-group">
								<label for="tagline">Zip Code</label>
								<input type="text" class="form-control input" id="tagline" name="zip" value="<?php echo $row['zip']?>" />
							</div>
						<div class="row">
							
							
							<div class="clearfix"></div>
							
						</div>

						
						<div class="form-group">
							<input type="submit" name="register" class="btn btn-default btn-blue" value="Create Account">
						</div>
					<?php  
					}
					?>
					</form>
					
					<div class="spacer-2">&nbsp;</div>
				</div>
				
				<div class="col-md-3">
					<div class="job-side-wrap" >
						
					<p align="center" style="width:100%; height:36px;background:#F75900;border-radius:3px;border:none;color:#fff;font-size:20px">
						Administration
					<div class="admin"><li><a href="editprofile.php">Edit Profile</a></li>
					  <li><a href="changepass.php">Change Password</a></li>
					  <li><a href="index.php">My Posted Jobs</a></li>
					  <li><a href="help.php">Help</a></li>
					  <li><a href="logout.php">Logout</a></li>
					
					</div>
					</div>
				
				</div>
				</div>
		</div>

		<?php include"footer.php";?>