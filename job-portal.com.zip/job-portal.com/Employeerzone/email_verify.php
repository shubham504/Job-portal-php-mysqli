<?php include"config.php";

if(isset($_POST['resetpass']))
{
$email=$_POST['email'];
$sql=mysql_query("select * from employeer where user_email='$email'");
if(!$sql)  
    { 
    die(mysql_error());   
    } 
if(mysql_affected_rows() != 0) 
    { 
$row=mysql_fetch_array($sql);
$to=$row['user_email']; 
$id=$row['id']; 

$t=time();
$reset=$row['password'].$t.$id; 

$subject="Jobsinagri.com - Password Recovery Request"; 
$header="From: Team@jobsinagri.com"; 
$content="Click on Link To Reset Your Password : http://jobsinagri.com/reset1.php?encrypt=$reset &action=reset "; 
mail($email, $subject, $content, $header);
if(mail){
$sql=mysql_query("update employeer set reset='$reset' where user_email='$to'") ;
$msg="A password Reset Link Sent to your Email ! Thank you"; 
}
    } 
else  
    { 
    $msg="Error : Email id not Found in our Record."; 
    } 
} 
?>

<html><head>
<title>
Jobs in Agri
</title>

<style>
.form{
width: 30%;
    float: left;
    margin-left: 35%;
    background: whitesmoke;
    margin-top: 170px;
    border-radius:6px;
.form-group{
width: 90%;
    float: left;
    margin-left: 5%;
    margin-top: 20px;
    }
   
 h2
{
width:100%;
text-align:center;
background-color:#F75900 !important;  
}
p{
width:100%;
}
</style>
</head>
<div class="form">
<?php 
$mail=$_GET['mail'];
$rand = rand(0,1000000000);
$sql=mysql_query("select * from employeer where user_email='$mail'");
if($row=mysql_fetch_array($sql))
{
$verify=$row['email_verify'];
if($verify=='')
{

$subject="Jobsinagri.com - Email Verification"; 
$header="From: jobsinagri.com"; 
$content="Your Verification code is : ".$rand;
 
mail($email, $subject, $content, $header);
$sql1=mysql_query("update employeer set email_verify='$rand' where user_email='$mail'");
if(mail){
echo"Verifaction Code Sent To Your Email Address";
}
else{
echo"Invalid Email Address";
}

}
else
{
echo"Code has been Expired or Invalid";
}

}
?>
<form action="#" method="post">

<h2 style="background: #F75900;
    height: 35px;
    margin-top: 0px;
    text-align: center;
    padding-top: 7px;
    color: #fff;
    text-transform: uppercase;
    border-top-right-radius: 6px;
    border-top-left-radius: 6px;"> Jobsinagri.com</h2>
    <div class="form-group">
        <label style="width: 80%;float: left;margin-left: 10%;font-size:23px;color:#a3a3a3">Email</label>
        <input type="email" placeholder=" Type your Registered Email" name="email" style="width: 80%;float: left;margin-left: 10%; height:40px;border:solid 1px #eee;border-radius:2px;font-size:18px" required />
    
    <input type="submit" value="SUBMIT" name="resetpass" style="width: 40%;float: left;margin-left: 30%;font-size:20px;color:#fff;background:#49C30B;border: none;
    border-radius: 5px;
    padding: 7px;
    margin-top: 20px;margin-bottom: 20px;  ">
    </form>
    <?php 
    if(isset($_POST['resetpass']))
    {
    echo"<p style='width:100%;text-align:center;color:red; float:left;'> $msg</p>";
    }
    ?>
    
    </div>
    </body></html>