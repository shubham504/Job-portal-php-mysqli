<?php include"header.php";

?>
		<div class="main-page-title">
					<div class="container">
				<div class="post-job-title">Your Previous Posted Job</div>
				<div class="post-job-phone">Any Query Call Us : 0141 - 3356493</div>
			</div>
		</div>
		<?php
		$sql="select* from employeer where user_email='$_SESSION[user]'";
$result=mysql_query($sql);
while($rowss=mysql_fetch_array($result))
{
$verify=$rowss['email_verify'];
if($verify!='omprakash')
{
echo"<div class='verifyemail'>Your Email Address is not Verified, to get Notification and Free Job Posting Verify Now <a href='verify_email.php?mail=$rowss[user_email]'>click here</a></div>";
}
}
?>
		<div class="container">
		<div class="spacer-1">&nbsp;</div>
			<div class="row"  style="min-height:300px;">
	<div class='col-md-9' >
	
			<?php
$sql="select* from job_post where user_email='$_SESSION[user]' order by ID desc";
$result=mysql_query($sql);
while($row=mysql_fetch_array($result))
{
	$logo=$row['logo'];
	?>
	<div style='width:100%;float:left;border:solid 1px #eee;padding-top:7px;padding-left:7px;margin:2px 5px;background:#F9F7F7;'>
	<?php
	echo "<div style='width:45%;float: left;text-transform: capitalize;font-size: 18px;color:#7B7474;font-family:sans-serif;'><a href='viewdetails.php?id=$row[id]'  style='color:blue'>$row[title]</a></div><div style='width:35%;float: left; text-transform: capitalize;font-size: 15px;color:#7B7474;font-family: sans-serif;'>Posted On : $row[date]</div><div style='width:19%;float: left;'  ><a href='resumes.php?id=$row[id]' style='float:right;color:#5C66B1' >View Resumes</a></div>";
echo"</div>";
				
		
			}	

?>

	</div>			
	<div class="col-md-3">
					

					

					<div class="job-side-wrap" >
						
					<p align="center" style="width:100%; height:36px;background:#F75900;border-radius:3px;border:none;color:#fff;font-size:20px">
						Administration
					<div class="admin"><li><a href="editprofile.php">Edit Profile</a></li>
					  <li><a href="#0" class="cd-popup-trigger">Change Password</a></li>
					  <li><a href="index.php">My Posted Jobs</a></li>
					  <li><a href="help.php">Help</a></li>
					  <li><a href="logout.php">Logout</a></li>
					
					</div>
					</div>
				</div>
			</div>
		</div>

	
<?php
include"footer.php";
?>