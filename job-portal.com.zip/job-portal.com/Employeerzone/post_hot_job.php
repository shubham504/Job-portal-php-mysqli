<?php
session_start();
include"header.php";
include"config.php";
if(isset($_POST['post']))
{
	
	$mail=$_POST['email'];
	$min=$_POST['min'];
	$max=$_POST['max'];
	
	$title=$_POST['title'];
	
	$location=$_POST['location'];
	$quali=$_POST['qualification'];
	
	$skill=$_POST['skill'];
	$type=$_POST['type'];
	$salary=$_POST['salary'];
	
	$category=$_POST['category'];
	$discription=$_POST['discription'];
	
	$appemail=$_POST['app_mail'];
	$cname=$_POST['company'];
	$website=$_POST['website'];
	$company_dis=$_POST['company_discription'];
	$file_name = $_FILES['logo']['name'];
	$user_email=$_SESSION['user'];
	$encoded_image =  base64_encode($file_name);
	$date=date("jS\ F Y ");
	$hot="1";
	$sql=mysql_query("insert into job_post (email,title,location,type,category,qualification,skill,salary,min_experience,max_experience,jobdiscription,app_email,company,website,company_discription, logo,user_email,date,hot_job) VALUES
	('$mail','$title','$location','$type','$category','$quali','$skill','$salary','$min','$max','$discription','$appemail','$cname','$website','$company_dis','$encoded_image','$user_email','$date','$hot')");
move_uploaded_file($_FILES['logo']['tmp_name'],"logo/".$encoded_image);
	 
	$msg1="Your Job Posted Successfully";
	
}


?>
		<div class="main-page-title"><!-- start main page title -->
			<div class="container">
				<div class="post-job-title">Post a Hot Job For Urgent Requirement</div>
				
			</div>
		</div><!-- end main page title -->
		<div class="container">
		<div class="spacer-1">&nbsp;</div>
			<div class="row">
<?php			
if(isset($_POST['post']))
{
			echo"<p>$msg1</p>";
}
			?>
				<div class="col-md-9">
					<form role="form" class="post-job-form" method="post" enctype="multipart/form-data">
						<div class="form-group">
							<label for="email">Your Email *</label>
							<input type="email" class="form-control input" id="email" name="email" placeholder="Application alerts will be send on this Email " required/>
						</div>
						<div class="form-group">
							<label for="jobtitle">Job Title *</label>
							<input type="text" class="form-control input" id="jobtitle" name="title" required/>
						</div>

						<div class="form-group">
							<label for="joblocation">Job Location * </label>
							<input type="text" class="form-control input" id="joblocation" placeholder="Location / confidential" name="location" required />
							
						</div>

						
						<div class="form-group">
							<label for="joblocation">Qualification * </label>
							<input type="text" class="form-control input" id="joblocation" placeholder="Seprate by Comma" name="qualification" required />
							
						</div>
<div class="form-group">
							<label for="joblocation">Skills * </label>
							<input type="text" class="form-control input" id="joblocation" placeholder="Seprate by Comma" name="skill" required />
							
						</div>

							<div class="form-group">
								<label  for="jobtag">Job Type *</label>
								<select class="form-control" name="type" required>
									<option value="Full Time">On Roll</option>
									<option value="Third Party">Third Party</option>
									<option value="Other">Other</option>
									
									</select>
							</div>
						
							<div class="form-group">
								<label  for="jobtag">Job Category *</label>
								<select class="form-control" name="category" required>
									<option value="R&D-seeds">R&D-seeds </option>
									<option value="R&D-chemicals">R&D-chemicals </option>
									<option  value="Registration">Registration</option>
									<option value="veterinary">veterinary</option>
									<option value="Tractor/ farm equipments">Tractor/ from equipments</option>
									<option value="Business Development">Business Development</option>
									<option value="Agri Finance">Agri Finance</option>
								        <option value="Poltry & Animal Husbandry">Poltry & Animal Feed </option>
									<option value="Warehousing and Commodity finance">Warehousing and commodity finance</option>
									<option value="Agri input-Seeds">Agri input-Seeds</option>
									<option value="Agri input-Pesticides">Agri input-Pesticides</option>
									<option value="Agri input Fertilizers">Agri input Fertilizers</option>
									<option value="Irrgation/ Drip">Irrgation/ Drip</option>
									<option value="Plantation">Plantation</option>
									<option value="Fisheries">Fisheries</option>
									<option value="procurement">Procurement</option>
									<option value="Seed Production">Seed Production</option>
									<option value="Product Development">Product Development</option>
									<option value="Education">Education</option>
									
								<option value="Other">Other</option>
								</select>
							</div>
						

						<div class="form-group">
								<label  for="jobtag"> Experience *</label></br>
								<select  name="min" required style="width:160px;border-radius:4px">
									<option disabled>Select Min Experience</option>
									<option value="0">0 Year</option>
									<option value="1">1 Year</option>
									<option value="2">2 Year</option>
									<option value="3">3 Year</option>
									<option value="4">4 Year</option>
									<option value="5">5 Year</option>
									<option value="6">6 Year</option>									
									<option value="7">7 Year</option>
									<option value="8">8 Year</option>
									<option value="9">9 Year</option>									
									<option value="10">10 Year</option>
									<option value="11">11 Year</option>
									<option value="12">12 Year</option>
								    <option value="13">13 Year</option>
								<option value="14">14 Year</option>
								<option value="15">15 Year</option>
								<option value="above">above</option>
								
								</select>
							<label  for="jobtag">To</label>
								<select class="" name="max" required style="width:160px;border-radius:4px">
									<option disabled>Select max Experience</option>
								<option value="0">0 Year</option>
								<option value="1">1 Year</option>
								<option value="2">2 Year</option>
								<option value="3">3 Year</option>
								<option value="4">4 Year</option>
								<option value="5">5 Year</option>
								<option value="6">6 Year</option>
								<option value="7">7 Year</option>
								<option value="8">8 Year</option>
								<option value="9">9 Year</option>
								<option value="10">10 Year</option>
								<option value="11">11 Year</option>
								<option value="12">12 Year</option>
								<option value="13">13 Year</option>
								<option value="14">14 Year</option>
								<option value="15">15 Year</option>
								<option value="16">16 Year</option>
								<option value="17">17 Year</option>
								<option value="18">18 Year</option>
								<option value="19">19 Year</option>
								<option value="20">20 Year</option>
								
								</select>
							
							</div>
						
						<div class="form-group">
							<label for="jobtag">Job Description *</label>
							<textarea class="form-control textarea" name="discription" required></textarea>
						</div>

						<div class="form-group">
							<label for="appemail">No of Position *</label>
							<input type="text" class="form-control input" id="appemail" name="app_mail" required/>
						</div>


						
												
						<div class="form-group">
								<label for="companyname">Company Name * </label>
								<input type="text" class="form-control input" placeholder="Name / confidential" id="companyname" name="company" required/>
							</div>

							<div class="form-group">
								<label for="tagline">Website * </label>
								<input type="text" class="form-control input" placeholder="Website / confidential" id="tagline" name="website" required/>
							</div>
							<div class="form-group">
								<label for="tagline">Salary * </label>
								<input type="text" class="form-control input" placeholder="per annum / As per Industry" id="tagline" name="salary" required/>
							</div>
						<div class="form-group">
							<label for="jobtag"> About Company</label>
							<textarea class="form-control textarea" name="company_discription" required></textarea>
						</div>
						<div class="form-group">
							<label for="logo">Logo <span>(Optional)</span></label>
							
								<input type="file" id="logo" name="logo" >
							
						</div>
						<div class="row">
							
							
							<div class="clearfix"></div>
							
						</div>
<div class="form-group">
							<input type="submit" name="post" value="POST JOB" class="btn btn-default btn-blue">
						</div>
						
						

					</form>
					<div class="spacer-2">&nbsp;</div>
				</div>
					<div class="col-md-3">
					

					

					<div class="job-side-wrap" >
						
					<p align="center" style="width:100%; height:36px;background:#F75900;border-radius:3px;border:none;color:#fff;font-size:20px">
						Administration
					<div class="admin"><li><a href="editprofile.php">Edit Profile</a></li>
					  <li><a href="changepass.php">Change Password</a></li>
					  <li><a href="index.php">My Posted Jobs</a></li>
					  <li><a href="help.php">Help</a></li>
					  <li><a href="logout.php">Logout</a></li>
					
					</div>
					</div>
				</div>
			</div>
		</div>

	
<?php
include"footer.php";
?>