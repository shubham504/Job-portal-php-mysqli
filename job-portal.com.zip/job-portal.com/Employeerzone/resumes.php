<?php
session_start();
include"header.php";
include"config.php";

?>
		<div class="main-page-title"><!-- start main page title -->
			<div class="container">
				<div class="post-job-title">Resume on your Posted job</div>
				</div>
		</div><!-- end main page title -->
		<div class="container">
		<div class="spacer-1">&nbsp;</div>
			<div class="row" style="min-height:340px;">
			<div class="col-md-12" style="padding:1px 1px;margin:2px 0px;background:whitesmoke; ">
	<table width="100%" border="1" style="border-color:silver;  font-family: serif;" >
   	<tr style="background-color:#F75900;line-height:30px;color:#fff"><th> &nbsp;Apply Date</th><th> &nbsp;Name</th><th> &nbsp;Age</th><th> &nbsp;Work Experience</th><th> &nbsp;Qualification</th><th> &nbsp;Current Employer</th> <th> &nbsp;Current City</th>
	<th> &nbsp;Current CTC</th><th> &nbsp;Mobile</th><th> &nbsp;Resume</th></tr>

			<?php
$id=$_GET['id'];

$sql=mysql_query("select* from apply where job_id='$id'");
while($row1=mysql_fetch_array($sql))
{
$sql1=mysql_query("select* from jobseekers where email='$row1[applicant_email]'");
if($row=mysql_fetch_array($sql1))
{
	$year=$row['dob_y'];
$dat=date('Y');
$age=$dat-$year;
}

echo"<tr><td>&nbsp;$row1[date] </td><td>&nbsp; $row[fullname]</td><td>&nbsp; $age yr</td><td>&nbsp; $row[experience] yrs</td><td>&nbsp; $row[pg]</td><td>&nbsp; $row[current_company]</td><td>&nbsp; $row[current_location]</td><td>&nbsp; $row[current_ctc]</td><td>&nbsp; $row[mobile]</td><td>&nbsp;<a href='viewresume.php?resume=$row[resume]' target='_blank' style='color:blue'> Download</a></td></tr>";

}
 
?>
</table>
</div>
		
	</div>
		</div>

	
<?php
include"footer.php";
?>