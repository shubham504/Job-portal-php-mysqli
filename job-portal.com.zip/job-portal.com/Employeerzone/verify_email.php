<?php include"config.php";

$email=$_GET['mail'];
if(isset($_POST['verify']))
{
$ver=$_POST['verification'];
$sql=mysql_query("select * from employeer where user_email='$email'");
if($row=mysql_fetch_array($sql))  
    { 
    $email_verify=$row['email_verify'];
    if($ver==$email_verify) 
    {
    $sql1=mysql_query("update employeer set email_verify='omprakash' where user_email='$email'");
    $msg="Your Email Address Successfully Verified ! Thank you";
    } 
    else{
    $msg="Invalid Verification Code";
    }
    } }
?>

<html><head>
<title>
Jobs in Agri
</title>

<style>
.form{
width: 30%;
    float: left;
    margin-left: 35%;
    background: whitesmoke;
    margin-top: 170px;
    border-radius:6px;
.form-group{
width: 90%;
    float: left;
    margin-left: 5%;
    margin-top: 20px;
    }
   
 h2
{
width:100%;
text-align:center;
background-color:#F75900 !important;  
}
p{
width:100%;
}
</style>
</head>
<div class="form">
<?php
if(isset($_GET['mail'])){
$mail=$_GET['mail'];
$rand = rand(0,1000000000);
$sql=mysql_query("select * from employeer where user_email='$mail'");
if($row=mysql_fetch_array($sql))

{
$verify=$row['email_verify'];
if($verify!='omprakash')
{
$sql1=mysql_query("update employeer set email_verify='$rand' where user_email='$mail'");

$subject="Jobsinagri.com - Email Verification"; 
$header="From:jobsinagri.com"; 
$content="Your Email Verification Code is :  ".$rand; 
mail($mail, $subject, $content, $header);
if(mail)
{
echo"A verification Code Sent To Your Email Address";
}
else{
echo"Error : Invalid  Email Address";
}
}
else{
echo"Email Id Successfully Verified";

}
}
}

?>
<form action="#" method="post">

<h2 style="background: #F75900;
    height: 35px;
    margin-top: 0px;
    text-align: center;
    padding-top: 7px;
    color: #fff;
    text-transform: uppercase;
    border-top-right-radius: 6px;
    border-top-left-radius: 6px;"> Jobsinagri.com</h2>
    <div class="form-group">
        <label style="width: 80%;float: left;margin-left: 10%;font-size:23px;color:#a3a3a3">Enter Your Verification Code</label>
        <input type="text" placeholder=" Verification Code Here" name="verification" style="width: 80%;float: left;margin-left: 10%; height:40px;border:solid 1px #eee;border-radius:2px;font-size:18px" required />
    
    <input type="submit" value="VERIFY" name="verify" style="width: 40%;float: left;margin-left: 30%;font-size:20px;color:#fff;background:#49C30B;border: none;
    border-radius: 5px;
    padding: 7px;
    margin-top: 20px;margin-bottom: 20px;  ">
    </form>
    <?php 
    if(isset($_POST['resetpass']))
    {
    echo"<p style='width:100%;text-align:center;color:red; float:left;'> $msg</p>";
    }
    ?>
    
    </div>
    </body></html>