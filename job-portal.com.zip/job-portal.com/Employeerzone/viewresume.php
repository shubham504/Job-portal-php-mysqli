<?php
session_start();
$resume=$_GET['resume'];
$r_path='../resumes/';
 header('Content-Description: File Transfer');
 header("Content-type: application/docx");
 header('Content-disposition:inline; filename='.$resume.'');
 header('Accept-Range:bytes');
   @readfile($r_path.$resume);
   ?>