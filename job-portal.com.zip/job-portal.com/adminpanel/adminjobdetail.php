<?php include"header.php";
include"config.php";

?>
<style>
.list ul {
	list-style:none;
width:auto;
	margin-left:5px;
	}
	.list ul li{
		display:inline;
		padding:3px;
		
	}
	.list ul li a{
		color:blue;
		font-size:14px;
	}
	.list .current{
		color:red !important;
		font-size:15px;
	}
	.previous{
		float:left;
		width:35px;
		margin-left:40px;
		background-color:#000;
		padding:auto;
		
	}
	.button{
		color:#fff;
	}
	.next{
		float:left;
		width:50px;
	}
</style>
				<div class="list">
					<div class="jobdetail">
					<?php			
					$idd=$_GET['idd'];
					$sql=mysql_query("select * from job_post where id='$idd'");
					if($row=mysql_fetch_array($sql))
					{
					echo"<div class='item1'>Urgent Requirement :</div>";
					if($row['hot_job']=='1'){ 
					echo"<div class='item2'>yes ! This is Hot Job</div>";
					} else
					{echo"<div class='item2'>No</div>";
					}
						
						
						echo"<div class='item1'> Job Title :</div><div class='item2'>  $row[title]</div> <div class='item1'> Posted on : </div><div class='item2'> $row[date]</div><div class='item1'> Company Name :</div> <div class='item2'> $row[company]</div><div class='item1'> Job Location :</div>
						<div class='item2'>$row[location]</div>
						<div class='item1'> Job Type :</div>
						<div class='item2'>$row[type]</div>
						<div class='item1'> Functional Area :</div>
						<div class='item2'>$row[category]</div>
						<div class='item1'> Required Qualification :</div>
						<div class='item2'>$row[qualification]</div>
						<div class='item1'> Job Skills :</div>
						<div class='item2'>$row[skill]</div>
						<div class='item1'> Package (per annum) :</div>
						<div class='item2'>$row[salary]</div>
						<div class='item1'> Experience :</div>
						<div class='item2'>$row[min_experience] - $row[max_experience] yrs </div>
						<div class='item1'> No of Positions :</div>
						<div class='item2'>$row[app_email]</div>
						<div class='item1'> Job Discription:</div>
						<div class='item2'>$row[jobdiscription]</div>
						<div class='item1'> About Company :</div>
						<div class='item2'>$row[company_discription]</div>
						<div class='item1'> Website :</div>
						<div class='item2'>$row[website]</div>
						<div class='item1'>User Email :</div>
						<div class='item2'>$row[user_email]</div>
						
						<div class='item1'>Company Logo :</div>
						<div class='item2'><img src='../Employeerzone/logo/$row[logo]' height='75'></div>
						";
					}
					
					?>
					</div>
				</div>
			</div>
		</div>
		<?php include "sidebar.php";?>
	</div>
</body>
</html>