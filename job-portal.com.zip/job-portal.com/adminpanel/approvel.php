<?php
include"config.php";
$iddd=$_GET['idd'];
$sql=mysql_query("update  job_post set approvel='1' where id='$iddd'");
$sql1=mysql_query("select * from job_post where id='$iddd'");
                if($row=mysql_fetch_array($sql1))
                {
                $email=$row['email'];
                $subject="Jobs Posted On Jobsinagri.com";
		$msg="Thank you ! Your Job Posted Successfully on JobsinAgri.com for more detail please visit: http://jobsinagri.com";
		 $from="Jobsinagri.com";
		
		$headers  = "From: " . $from . "\r\n"; 
		$headers .= "Reply-To: 'info@jobsinagri.com'\r\n"; 
		$headers .= "MIME-Version: 1.0\r\n"; 
		$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n"; 
		mail($email, $subject, $msg, $headers);
		 }
echo"<script>alert('Job Approved Successfully')</script>";
echo"<script>window.location='unapprove_jobs.php'</script>";
?>