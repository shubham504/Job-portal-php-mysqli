<?php include"header.php";
include"config.php";
if(isset($_POST['save']))
{
	echo $old=md5($_POST['opass']);
	
	$npass=$_POST['npass'];
	$cpass=$_POST['cpass'];
	
$sql=mysql_query("select* from admin where username='$_SESSION[user]' ");

if($row=mysql_fetch_array($sql))
{
 
$oldpass=$row['password'];
	if($oldpass==$old)
	{
		if($npass==$cpass)
		{
		$sql=mysql_query("update admin set password=md5('$npass') where username='$_SESSION[user]'");
	   $msge = 'Password Changes successfully';
	   }
		else{
			$msge = "Password are not Same";
}

	}
		else
		{
			$msge = "Old Password is not Correct";
		}
}}
?>
<style>
.list ul {
	list-style:none;
width:auto;
	margin-left:5px;
	}
	.list ul li{
		display:inline;
		padding:3px;
		
	}
	.list ul li a{
		color:blue;
		font-size:14px;
	}
	.list .current{
		color:red !important;
		font-size:15px;
	}
	.previous{
		float:left;
		width:35px;
		margin-left:40px;
		background-color:#000;
		padding:auto;
		
	}
	.button{
		color:#fff;
	}
	.next{
		float:left;
		width:50px;
	}
	p{
		color:green;
		margin-left:330px;
		font-size:15px;
	}
</style>
				<div class="list">
				<form action="" method="post">
				
					<table width="35%"  class="seeker" style="margin-left:200px;line-height:40px">		
					
					<tr ><th>Old Password</th><td colspan="2"><input type="password" name="opass"   style="width:300px;line-height:23px;" required></td></tr>
					<tr ><th>New Password</th><td colspan="2"><input type="password" name="npass"  style="width:300px;line-height:23px;" requierd></td></tr>
					<tr ><th>Confirm Password</th><td colspan="2"><input type="password" name="cpass"  style="width:300px;line-height:23px;" required></td></tr>
						
				
					<tr colspan="2"><th colspan="2"> <input type="submit" name="save" value="Update"></th></tr>
				
				</table>
				</form>
<?php
if(isset($_POST['save']))
{
echo "<p>$msge</p>";
echo"<div class='clear'></div>";
} ?>
				</div>
			</div>
		</div>
		<?php include "sidebar.php";?>
	</div>
</body>
</html>