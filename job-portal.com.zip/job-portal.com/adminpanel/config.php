<?php

$conn=mysql_connect("localhost","root","");			
mysql_selectdb("destinat_jobsinagri",$conn);
?>