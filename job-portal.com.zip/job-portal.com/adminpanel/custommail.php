<?php include"config.php"; 
include"header.php";?>
		<?php
		if(isset($_POST['send']))
		{
		$subject=$_POST['subject'];
		$msg=$_POST['message'];
		 $recvr=$_POST['receiver'];
		$custom=$_POST['custom'];
		$from="Jobsinagri.com";
		
		$headers  = "From: " . $from . "\r\n"; 
		$headers .= "Reply-To: 'info@jobsinagri.com'\r\n"; 
		$headers .= "MIME-Version: 1.0\r\n"; 
		$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n"; 

		if($recvr=='custom')
		{				
		mail($custom, $subject, $msg, $headers);
		 
		if(mail) 
		{ 
		$msge="An Email sent successfully to Custom User !"; 
		} 
		else 
		{ 
		$msge="Problem sending Email to User"; 
		}
		}
		
	           	if($recvr=='employer')	
			{
			$sql=mysql_query("select * from employeer");
			while($row=mysql_fetch_array($sql))
			{
			$email=$row['user_email'];
			mail($email, $subject, $msg, $headers);
			}
			if(mail)
			{
			$msge="Email Sent Successfull To All Employer's";
			}
			else{
			$msge="Error ! Problem Sending Email To Employer's";
	                
			} 
			}
			         if($recvr=='seeker')
		                 {
			
				$sql=mysql_query("select * from jobseekers");
				while($rows=mysql_fetch_array($sql))
				{
				$emails=$rows['email'];
				mail($emails, $subject, $msg, $headers);
				} 
				if(mail)
				{
				$msge="Email Sent Successfull To All Seeker's";
				}
				else{
				$msge="Error ! Problem Sending Email To JobSeeker's";
		
				}
							} 
					if($recvr=='alluser')
					{
					
					$sql=mysql_query("select * from employeer");
					while($row=mysql_fetch_array($sql))
					{
					$email=$row['user_email'];
					mail($email, $subject, $msg, $headers);
					} 
			                $sql=mysql_query("select * from jobseekers");
					while($rows=mysql_fetch_array($sql))
					{
					$emails=$rows['email'];
					mail($emails, $subject, $msg, $headers);
					} 
					if(mail)
					{
					$msge="Email Sent Successfull To All User's";
					}
					else{
					$msge="Error ! Problem Sending Email To User's";
			
					}
					} 				
		 }
		?>
		
				<div class="tabs">
					<div id="tab-1" class="tab">
						<article>
							<div class="text-section">
								<h1>Dashboard</h1>
							</div>
							
						</article>
						<?php if(isset($_POST['send']))
						{
						echo"<p style='color:red'>$msge</p>";
						}
						?>
					</div><h3>Please Type Subject and Message</h3>
					
			<form action="#" method="post">
			
			<p><input type="text"  name="subject" placeholder=" Subject *" required style="width:400px;height:25px;font-size:15px;border:solid 1px gray;border-radius:3px"></p>
			
			<p><textarea  name="message" placeholder=" Message *" required style="width:600px;height:150px;font-size:15px;border:solid 1px gray;border-radius:6px"></textarea></p>
			<h3>Plese Choose a Recipient </h3>
			
			<p> <select name="receiver" id="contactinfo" style="width:300px;height:30px;font-size:15px;border:solid 1px gray;border-radius:2px">
			<option value="default" >---Select a recipient---</option>
			<option value="custom" >Custom User</option>
			 <option value="employer">All Employers</option>
			<option value="seeker">All Seekers</option>
			<option value="alluser">All Users </option>
			</select></p>
			<div id="email" style="display: none;"> <input type="email" name="custom" placeholder="Type a Email" style="width:400px;height:25px;font-size:15px;border:solid 1px gray;border-radius:3px" /></div><br>
			<p> <input type="submit" name="send" value="Send" class="btn0" style="width:150px;height:30px;font-size:15px;border:none"></p>
			
			</form> 	
			</div>
		</div></div>
		<?php include "sidebar.php";?>
	</div>
	<script type="text/javascript">
	$(document).ready(function(){
	    $('#contactinfo').on('change', function() {
	      if ( this.value == 'custom')
	      //.....................^.......
	      {
	        $("#email").show();
	      }
	      else
	      {
	        $("#email").hide();
	      }
	    });
	});
</script>
</body>
</html>