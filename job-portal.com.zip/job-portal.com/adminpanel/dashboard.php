<?php include"header.php";?>
				
				<div class="tabs">
					<div id="tab-1" class="tab">
						<article>
							<div class="text-section">
								<h1>Dashboard</h1>
							</div>
							
						</article>
					</div>
					<div class="step1"><a href="sendmail.php?id='seekers'"><div class="icons"><img src="images/message.png"></div><p>SEND EMAIL TO SEEKERS</p></a></div>
					<div class="step2"><a href="employermail.php"><div class="icons"><img src="images/message.png"></div><p>SEND EMAIL EMPLOYER</p></a></div>
					<div class="step1"><a href="custommail.php"><div class="icons"><img src="images/message.png"></div><p>SEND CUSTOM EMAIL</p></a></div>
					<div class="step2"><a href="seeker.php"><div class="icons"><img src="images/posted.png"></div><p>TOTEL EMPLOYEE : <?php  $result = mysql_query("SELECT * FROM jobseekers");
$rows = mysql_num_rows($result);
echo $rows ; ?></p></a></div>
					<div class="step1"><a href="employee.php"><div class="icons"><img src="images/posted.png"></div><p>TOTEL EMPLOYER : <?php $result = mysql_query("SELECT * FROM employeer");
$rows = mysql_num_rows($result);
echo $rows ; ?></p></a></div>
					<div class="step2"><a href="approve_jobs.php"><div class="icons"><img src="images/message.png"></div><p>TOTEL POST : <?php $result = mysql_query("SELECT * FROM job_post");
$rows = mysql_num_rows($result);
echo $rows ; ?></p></a></div>
					
					<div class="step1"><a href='approve_jobs.php'><div class="icons"><img src="images/posted.png"></div><p>TODAY'S POST : <?php $date=date("jS\ F Y"); $result = mysql_query("SELECT * FROM job_post where date='$date'");
$rows = mysql_num_rows($result);
echo $rows ; ?></span></p></a></div>
				</div>
			</div>
		</div>
		<?php include "sidebar.php";?>
	</div>
</body>
</html>