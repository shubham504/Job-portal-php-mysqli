<?php
 include"header.php";
include"config.php";

$sql=mysql_query("delete from contact where id='$_GET[c_id]'");
echo"<script>alert('Message deleted Successfully')</script>";
echo"<script>window.location='contact.php'</script>";

?>