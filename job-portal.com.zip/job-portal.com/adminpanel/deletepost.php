<?php
include'config.php';
$sql=mysql_query("delete from job_post where id='$_GET[idd]'");
echo"<script>alert('data deleted successfully')</script>";
echo"<script>location.href='approve_jobs.php'</script>";

?>