<?php
include'config.php';
$sql=mysql_query("delete from services where id='$_GET[id]'");
echo"<script>alert('data deleted successfully')</script>";
echo"<script>location.href='services.php'</script>";

?>