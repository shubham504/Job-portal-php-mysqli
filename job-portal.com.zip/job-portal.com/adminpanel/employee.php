<?php include"header.php";
include"config.php";

?>
<style>
.list ul {
	list-style:none;
width:auto;
	margin-left:5px;
	}
	.list ul li{
		display:inline;
		padding:3px;
		
	}
	.list ul li a{
		color:blue;
		font-size:14px;
	}
	.list .current{
		color:red !important;
		font-size:15px;
	}
	.previous{
		float:left;
		width:35px;
		margin-left:40px;
		background-color:#000;
		padding:auto;
		
	}
	.button{
		color:#fff;
	}
	.next{
		float:left;
		width:50px;
	}
</style>
				<div class="list">
					<table width="98%"  class="seeker" border="1" style="border-collapse: collapse;">		
					<tr><th>S.No</th><th>Company Name</th><th>Email</th><th>Address</th><th>Registration date</th><th>Detail</th></tr>
				<?php
				$start=0;
$limit=10;

if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$start=($id-1)*$limit;
}


				$sql=mysql_query("select * from employeer order by id desc LIMIT $start, $limit");
				$sno=0;
				while($row=mysql_fetch_array($sql))
				{ $sno=$sno+1;
					echo "<tr><td width='3%'>$sno</td><td width='15%'>$row[company]</td><td width='15%'> $row[user_email]</td><td width='15%'>$row[city], $row[state], $row[zip]</td>
					<td width='12%'>$row[reg_date]</td><td width='12%'><a href='employeerdetail.php?e_id=$row[id]'>View</a></td></tr>";
				}
				$rows=mysql_num_rows(mysql_query("select * from jobseekers"));
$total=ceil($rows/$limit);
$id='';

echo "<ul class='page'>";
		for($i=0;$i<=$total;$i++)
		{
			if($i==$id)
				{ echo "<li class='current'>".$i."</li>";
             
			 $id=$id++;		
			 }
			
			else {
				echo "<li><a href='?id=".$i."'>".$i."</a></li>"; }
		$id=$id++;
		}
echo "</ul>";
				?>
				</table>

				</div>
			</div>
		</div>
		<?php include "sidebar.php";?>
	</div>
</body>
</html>