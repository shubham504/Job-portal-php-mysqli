<?php include"config.php"; 
include"header.php";?>
		<?php
		if(isset($_POST['submit']))
		{
		$sql=mysql_query("select * from apply");
		while($row=mysql_fetch_array($sql))
		{
		
		$email=$row['company_email'];
		 $date=date("jS\ F Y");
		$subject="Jobsinagri.com - New Resumes for You";  
	$sql1=mysql_query("select * from apply where company_email='$email' AND date='$date'");
	$rows=mysql_fetch_array($sql1);
	if($rows){
	$message="New People Applied for Your Posted Job at JOBS IN AGRI. to View Resumes click here http://jobsinagri.com/employeerZone.php";
 
$from="Jobsinagri.com";
$headers  = "From: " . $from . "\r\n"; 
$headers .= "Reply-To: ". $from . "\r\n"; 
$headers .= "MIME-Version: 1.0\r\n"; 
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n"; 
mail($email, $subject, $message, $headers);
} 
else{
}
if(mail) 
{ 
$msg='An Email sent successfully to all Employer!'; 
} 
else 
{ 
$msg= 'Problem sending Email to Employer'; 

		}
		}
		}
		?>
		
				<div class="tabs">
					<div id="tab-1" class="tab">
						<article>
							<div class="text-section">
								<h1>Dashboard</h1>
							</div>
							
						</article>
					</div>
					<h3>are you sure you want to send email</h3>
					
			<form action="#" method="post"><input type="submit" name="submit" value=" SEND " class="btn2" style="padding:5px 20px;border:none;font-size:20px">
			</form> </br><a href="dashboard.php" class="btn1" style="padding:5px 20px;border:none;font-size:16px"> CANCEL</a><br><br>
			<?php
			if(isset($_POST['submit']))
			{
			echo "<p style='color:green;font-size:15px;'>$msg</p>";
			}
			?> 		
			</div>
		</div></div>
		<?php include "sidebar.php";?>
	</div>
</body>
</html>