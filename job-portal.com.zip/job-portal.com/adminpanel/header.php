<?php 
session_start();
include"config.php";
// if(($_SESSION['user']=='')||($_SESSION['password']==''))
// {
	// echo"<script>window.location='index.php'</script>";

// }
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="utf-8">
	<title>AdminPanel</title>
	
	<link media="all" rel="stylesheet" type="text/css" href="css/all.css" />
	
	<script type="text/javascript">window.jQuery || document.write('<script type="text/javascript" src="js/jquery-1.7.2.min.js"><\/script>');</script>
	<script type="text/javascript" src="js/jquery.main.js"></script>
	<!--[if lt IE 9]><link rel="stylesheet" type="text/css" href="css/ie.css" /><![endif]-->
</head>
<body>
	<div id="wrapper">
		<div id="content">
			<div class="c1">
				<div class="controls">
					<nav class="links">
						<ul>
							<li><a href="contact.php" class="ico1">Messages <span class="num"><?php $result = mysql_query("SELECT * FROM contact");
$rows = mysql_num_rows($result);
echo $rows ; ?></span></a></li>
							<li><a href="unapprove_jobs.php" class="ico2">Approvel Pending <span class="num"><?php $result = mysql_query("SELECT * FROM job_post where approvel='0'");
$rows = mysql_num_rows($result);
echo $rows ; ?></span></a></li>
				<!-- <li><a href="#" class="ico3">Documents <span class="num">3</span></a></li> -->
						</ul>
					</nav>
					<div class="profile-box">
						<span class="profile">
							<a href="#" class="section">
								<img class="image" src="images/adminlogo.png" alt="image description" width="26" height="26" />
								<span class="text-box">
									Welcome
									<strong class="name">Admin</strong>
								</span>
							</a>
							
						</span>
						<a href="logout.php" class="btn-on" title="logout">On</a>
					</div>
				</div>