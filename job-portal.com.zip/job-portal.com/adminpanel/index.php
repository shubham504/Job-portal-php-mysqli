<?php  
session_start();
include"config.php";

if(isset($_POST['login']))
{
	$user=$_POST['username'];
	
	$pass=$_POST['password'];
	$sql=mysql_query("select * from admin where username='$user' and password=md5('$pass')");
	if($res=mysql_fetch_array($sql))
	{
		$_SESSION['user']=$res['username'];
		$_SESSION['password']=$res['password'];
		echo"<script>window.location='dashboard.php'</script>";
	}
	else{
		$msg="Invalid username or Password";
	}
}
?>
<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<title>AdminPanel</title>
	<style>
	p{
		color:red;
		text-align:center;
	}
	.login{
	width:30%;
	margin:35%; 
	margin-top:100px;
	border:solid 1px silver; 
	background-color:#fff;
	}
	.login input{
	width:70%;
	margin-left:15%;
	margin-top:5px;
	height:30px;
	border-radius:3px;
	border:solid 1px #e3e3e3;
	margin-bottom:15px;
	color:#3A300D;
	}
	label{
	margin-left:15%;
	margin-top:10px;
	color:#807D7D;
	}
	
	body{
	background-color:#E4E7EE;
	width:100%;
	height:500px;
	
	}
	</style>
	
</head>
<body>
<div class="login">
<form action="<?php echo filter_var($_SERVER['PHP_SELF'], FILTER_SANITIZE_STRING); ?>" method="post">
<h2 align="center">JobsinAgri Admin Panel</h2>
<label>Username *</label>
<input type="text" name="username"  autofill="off" required></br> 
<label>Password *</label>
<input type="password" name="password"  required autofill="off"> 
<input type="submit" name="login" value="LOGIN">

</form>
<?php
if(isset($_POST['login']))
{
echo"<p>$msg</p>";	
}
?>
<label>Forgot Password&nbsp; <a href="admin_forgot.php"> Click Here</a>
</label>
<br><br>
</div>

</body>
</html>