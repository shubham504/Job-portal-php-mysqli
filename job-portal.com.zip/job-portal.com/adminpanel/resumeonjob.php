<?php include"header.php";
include"config.php";

?>
<style>
.list ul {
	list-style:none;
width:auto;
	margin-left:5px;
	}
	.list ul li{
		display:inline;
		padding:3px;
		
	}
	.list ul li a{
		color:blue;
		font-size:14px;
	}
	.current{
		color:red !important;
		font-size:15px;
	}
	.previous{
		float:left;
		width:35px;
		margin-left:40px;
		background-color:#000;
		padding:auto;
		
	}
	.button{
		color:#fff;
	}
	.next{
		float:left;
		width:50px;
	}
</style>
				<div class="list">
					<table width="98%"  class="seeker" border="1">		
					<tr><th>S.NO</th><th>Name</th><th>Email</th><th>Location</th><th>Experience</th><th>Functional Area</th><th>Resume</th><th>Last Updation</th><th>Detail</th></tr>
				<?php

$sno=0;
				$sql=mysql_query("select * from apply where job_id='$_GET[j_id]'");
				while($row=mysql_fetch_array($sql))
				{
				$app_email=$row['applicant_email'];
				
				$sno=$sno+1;
					$sql1=mysql_query("select * from jobseekers where email='$app_email'" );
				while($row1=mysql_fetch_array($sql1))
				{
					
					echo "<tr><td width='3%'>$sno</td><td width='12%'>$row1[fullname]</td><td width='12.5%'> $row1[email]</td><td width='12%'>$row1[current_location]</td>
					<td width='12%'>$row1[experience]</td><td width='12.5%'>$row1[functional_area]</td><td width='12%'><a href='../Employeerzone/viewresume.php?resume=$row1[resume]' style='color:blue'>Download</a></td><td width='12%'>$row1[date]</td><td width='10%'><a href='seekerdetail.php?s_id=$row1[id]'>View</a></td></tr>";
				}}
				
				?>
				</table>

				</div>
			</div>
		</div>
		<?php include "sidebar.php";?>
	</div>
</body>
</html>