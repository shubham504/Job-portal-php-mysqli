<?php include"header.php";
include"config.php";

?>
<style>
.list ul {
	list-style:none;
width:auto;
	margin-left:5px;
	}
	.list ul li{
		display:inline;
		padding:3px;
		
	}
	.list ul li a{
		color:blue;
		font-size:14px;
	}
	.current{
		color:red !important;
		font-size:15px;
	}
	.previous{
		float:left;
		width:35px;
		margin-left:40px;
		background-color:#000;
		padding:auto;
		
	}
	.button{
		color:#fff;
	}
	.next{
		float:left;
		width:50px;
	}
</style>
				<div class="list">
				<div class="jobdetail">
					
				<?php
			
				$sql=mysql_query("select * from jobseekers where id='$_GET[s_id]'");
				
				while($row=mysql_fetch_array($sql))
				{
						echo"<div class='item1'> Full Name :</div><div class='item2'>  $row[fullname]</div> <div class='item1'> User Email : </div><div class='item2'> $row[email]</div><div class='item1'> Contact :</div> <div class='item2'> $row[mobile]</div><div class='item1'> Current Location :</div>
						<div class='item2'>$row[current_location]</div>
						<div class='item1'> Permanent Address :</div>
						<div class='item2'>$row[per_address]</div>
						<h2>Qualification</h2>
						<div class='item1'> Graduation :</div>
						<div class='item2'>$row[ug]</div>
						<div class='item1'> Graduation University :</div>
						<div class='item2'>$row[ug_university]</div>
						<div class='item1'> Post Graduation :</div>
						<div class='item2'>$row[pg_university]</div>
						<h2>About Work</h2>
						<div class='item1'> Current Company :</div>
						
						<div class='item2'>$row[current_company]</div>
						<div class='item1'> Current CTC :</div>
						<div class='item2'>$row[current_ctc] Rs per annum </div>
						<div class='item1'> Expected CTC :</div>
						<div class='item2'>$row[exp_ctc] Rs per annum</div>
						<div class='item1'> Work Experience:</div>
						<div class='item2'>$row[experience] yrs</div>
						<div class='item1'> Job Preferred:</div>
						<div class='item2'>$row[pre_location]</div>
						<div class='item1'> Key Skills</div>
						<div class='item2'>$row[keyskill]</div>
						<div class='item1'>Functional Area :</div>
						<div class='item2'>$row[functional_area]</div>
						<div class='item1'>Language :</div>
						<div class='item2'>$row[lan1], $row[lan2], $row[lan3]</div>
						<div class='item1'>Registration Date :</div>
						<div class='item2'>$row[date]</div>
						<div class='item1'>Last update :</div>
						<div class='item2'>$row[last_update]</div>
						
						<div class='item1'>Resume :</div>
						<div class='item2'><a href='../Employeerzone/viewresume.php?resume=$row[resume]' style='color:blue'>Downlaod</a></div>";
					}
				?>
				</div>

				</div>
			</div>
		</div>
		<?php include "sidebar.php";?>
	</div>
</body>
</html>