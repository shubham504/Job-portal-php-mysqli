<?php include"config.php"; 
include"header.php";?>
		<?php
		if(isset($_POST['submit']))
		{
		$sql=mysql_query("select * from jobseekers");
		while($row=mysql_fetch_array($sql))
		{
		
		 $date=date("jS\ F Y");
		$subject="Jobsinagri.com - Latest Jobs For You"; 
$message = '<!DOCTYPE HTML>'. 
'<head>'. 
'<meta http-equiv="content-type" content="text/html">'. 
'<title>Email notification</title>'. 
'</head>'. 
'<body style="width:97%;margin:auto;border:solid 1px #eee;border-radius:8px;">'. 
'<div id="header" style="width: 97.45%;height: 30px;border-radius:4px;padding: 10px;font-size:20px;color: #fff;text-align:left;background-color:#49C30B;font-family: Open Sans,Arial,sans-serif;"> Jobsinagri.com - Latest Job Opening For You
</div>'; 
	$sql1=mysql_query("select * from job_post where approvel='1' AND date='$date'");
		while($rows=mysql_fetch_array($sql1))
		{
		 
	$cont=
$message.='<div id="outer" style="width: 100%;margin: 0 auto;margin-top:0px;">'.  
   '<div id="inner" style="width: 89%;border-radius:4px;margin:4.7%;background-color: #fff;font-family: Open Sans,Arial,sans-serif;font-size: 13px;font-weight: normal;line-height: 1.4em;color: #444;margin-top: -18px;">'. 
       '<p style="background-color:#eee;font-size:18px;width:100%;line-height:1em;padding:8px 10px;">'.$rows['title'].'('.$rows['min_experience'].'-'.$rows['max_experience'].' yrs   )</p>'. 
       '<p style="color: #787171;font-size:16px"> <b>Company name :</b>'.$rows['company'].'</p>'. 
       '<p style="color: #49C30B;font-size:16px"> <b>Job Location :</b>'.$rows['location'].'</p>'. 
       '<p> <b>Package Per Annum :</b> '.$rows['salary'].'</p>'. 
       '<p><a href="http://jobsinagri.com/seeker_registration.php" style="background:#F75900;padding:7px;font-size:15px;color:#fff;border-radius: 4px;text-transform: uppercase;
    text-decoration: none;">Apply Now</p>'. 
   '</div>'.   
'</div>';
}

$message.='<div id="footer" style="width: 97.45%;font-size:16px;height: 30px;text-align: center;padding: 10px;font-family: Verdena;background-color: #eee;">'. 
   'JOBSINAGRI.COM | developed by<a href="http://www.inventiveinfosys.com" style="color:#787171"> INVENTIVE INFOSYS </a>'. 
'</div>'. 
'</body>'; 
$email=$row['email'];

$from="Jobsinagri.com";
$headers  = "From: " . $from . "\r\n"; 
$headers .= "Reply-To: ". $from . "\r\n"; 
$headers .= "MIME-Version: 1.0\r\n"; 
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n"; 
mail($email, $subject, $message, $headers);
} 
if(mail) 
{ 
$msg='An Email sent successfully to all Jobseekers!'; 
} 
else 
{ 
$msg= 'Problem sending Emailto Job Seekers'; 

		}}
		?>
		
				<div class="tabs">
					<div id="tab-1" class="tab">
						<article>
							<div class="text-section">
								<h1>Dashboard</h1>
							</div>
							
						</article>
					</div>
					<h3>are you sure you want to send email</h3>
					
			<form action="#" method="post"><input type="submit" name="submit" value=" SEND " class="btn2" style="padding:5px 20px;border:none;font-size:20px">
			</form> </br><a href="dashboard.php" class="btn1" style="padding:5px 20px;border:none;font-size:16px"> CANCEL</a><br><br>
			<?php
			if(isset($_POST['submit']))
			{
			echo "<p style='color:green;font-size:15px;'>$msg</p>";
			}
			?> 		
			</div>
		</div></div>
		<?php include "sidebar.php";?>
	</div>
</body>
</html>