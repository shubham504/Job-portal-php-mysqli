<aside id="sidebar">
			<strong class="logo"><a href="#">Jobsinagri</a></strong>
			<ul class="tabset buttons">
				<li class="active">
					<a href="dashboard.php" class="ico1"><span>Dashboard</span><em></em></a>
					<span class="tooltip"><span>Dashboard</span></span>
				</li>
				<li>
					<a href="seeker.php" class="ico4"><span>Seekers</span></a>
					<span class="tooltip"><span>Seekers</span></span>
				</li>
				<li>
					<a href="employee.php" class="ico4"><span>Employers</span><em></em></a>
					<span class="tooltip"><span>Employeers</span></span>
				</li>
				
				<li>
					<a href="approve_jobs.php" class="ico4"><span>Approved Jobs</span><em></em></a>
					<span class="tooltip"><span>approved Jobs</span></span>
				</li>
				<li>
					<a href="unapprove_jobs.php" class="ico4"><span>Unapproved Jobs</span><em></em></a>
					<span class="tooltip"><span>unapproved Jobs</span></span>
				</li>
				
				<li>
					<a href="services.php" class="ico5"><span>Services</span><em></em></a>
					<span class="tooltip"><span>Services</span></span>
				</li>
				<li>
					<a href="#tab-6" class="ico6">
						<span>Contact us</span><em></em>
					</a>
					
					<span class="tooltip"><span>Contact us</span></span>
				</li>
				<li>
					<a href="changepass.php" class="ico7"><span>Change Password</span><em></em></a>
					<span class="tooltip"><span>Change Password</span></span>
				</li>
				<li>
					<a href="editprofile.php" class="ico8"><span>Profiel Settings</span><em></em></a>
					<span class="tooltip"><span>Profile Settings</span></span>
				</li>
			</ul>
			<span class="shadow"></span>
		</aside>