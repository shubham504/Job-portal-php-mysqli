<?php
include("config.php");
elseif($_POST["page"] == "users_login") 
	{
		$user_email = trim(strip_tags($_POST['email']));
		$user_password = trim(strip_tags($_POST['passwd']));
		$encrypted_md5_password = md5($user_password);
		
		$validate_user_information = mysql_query("select * from `admin` where `username` = '".mysql_real_escape_string($user_email)."' and `password` = '".mysql_real_escape_string($encrypted_md5_password)."'");
		
		if(mysql_num_rows($validate_user_information) == 1)
		{
			$get_user_information = mysql_fetch_array($validate_user_information);
			$_SESSION["user"] = $user_email;
			//$_SESSION["USER_FULLNAME"] = strip_tags($get_user_information["firstname"].'&nbsp;'.$get_user_information["lastname"]);
			//echo 'index.php?uid='.$_SESSION["USER_FULLNAME"].'&';
			echo 'login_process_completed_successfully=yes';
		}
		else
		{
			echo '<br><div class="info">Sorry, you have provided incorrect information. Please enter correct user information to proceed. Thanks.</div><br>';
		}
	}
	//Login Page Ends here
}
?>