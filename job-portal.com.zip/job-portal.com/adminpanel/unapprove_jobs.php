<?php include"header.php";
include"config.php";

?>
<style>
.list ul {
	list-style:none;
width:auto;
	margin-left:5px;
	}
	.list ul li{
		display:inline;
		padding:3px;
		
	}
	.list ul li a{
		color:blue;
		font-size:14px;
	}
	.list .current{
		color:red !important;
		font-size:15px;
	}
	.previous{
		float:left;
		width:35px;
		margin-left:40px;
		background-color:#000;
		padding:auto;
		
	}
	.button{
		color:#fff;
	}
	.next{
		float:left;
		width:50px;
	}
</style>
				<div class="list">
					<table width="95%"  class="seeker" border="1">		
					<tr><th>Company Name</th><th>Email</th><th>Job Title</th><th>Posted date</th><th>Approval</th><th>Action</th></tr>
				<?php
				$start=0;
$limit=10;

if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$start=($id-1)*$limit;
}

$app=0;
				$sql=mysql_query("select * from job_post where approvel='$app' LIMIT $start, $limit ");
				
				while($row=mysql_fetch_array($sql))
				{
					echo "<tr><td width='15%'>$row[company]</td><td width='15%'> $row[email]</td><td width='15%'>$row[title]</td>
					<td width='15%'>$row[date]</td><td width='9%'>Pending</td><td width='23%'><a href='adminjobdetail.php?idd=$row[id]'class='btn0'>View</a> <a href='deletepost.php?idd=$row[id]' class='btn1'> Delete </a> &nbsp;<a href='approvel.php?idd=$row[id]' class='btn2'> approve</a> </td></tr>";
				}
				$rows=mysql_num_rows(mysql_query("select * from job_post"));
$total=ceil($rows/$limit);
$id='';

echo "<ul class='page'>";
		for($i=0;$i<=$total;$i++)
		{
			if($i==$id)
				{ echo "<li class='current'>".$i."</li>";
             
			 $id=$id++;		
			 }
			
			else {
				echo "<li><a href='?id=".$i."'>".$i."</a></li>"; }
		$id=$id++;
		}
echo "</ul>";
				?>
				</table>

				</div>
			</div>
		</div>
		<?php include "sidebar.php";?>
	</div>
</body>
</html>