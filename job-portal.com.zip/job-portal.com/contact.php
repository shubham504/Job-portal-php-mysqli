<?php include"config.php"; 
include"header.php"; ?>
		<div class="job-finder">
			<div class="container">
				<h3>Leave A Message</h3>
				<?php
				if(isset($_GET['register']))
{
	
	$name=$_GET['name'];
	
	$email=$_GET['email'];
	
	$mobile=$_GET['mobile'];
	
	$message=$_GET['message'];
	
	$sql=mysql_query("insert into `contact`(`name`, `email`, `mobile`, `message`)values('$name','$email','$mobile','$message')");
	
	echo "<p style='color:#61B911'>Thank you for Connecting With us ! we will contact you soon </p>";
	}


				?>
				<form 	action="" method="get">
					<div class="col-md-7 form-group group-1">
						<label for="searchjob" class="label">Name</label>
						<input type="text" id="searchjob" class="input-job" placeholder="Your Name" name="name" required>
					<label for="searchjob" class="label">Email</label>
						<input type="email" id="searchjob" class="input-job" placeholder="Email" required name="email">
					<label for="searchjob" class="label">Contact</label>
						<input type="text" id="searchjob" class="input-job" placeholder="10 Digit Valiid Mobile No" name="mobile" required>
					<label for="searchjob" class="label">Message</label>
						<textarea  class="input-job" style="height:200px;" name="message" required> </textarea>
					<input type="submit" class="btn btn-default btn-green" value="Send" name="register">
				</form>
				
					</div>
					<div class="col-md-5 form-group group-2">
					<div style="margin-left:100px" >
						<label for="searchplace" class="label">Need Help</label><br>
						</br>Call us : 0141 -3356493
						<br>Email : info@jobsinagri.com<br><br><label for="searchplace" class="label">Working hour</label>
						<br>Monday to Saturday : 9.30 am to 7.30 pm
						</div>
						</div>
				
					
					
			</div>
		</div>
		<!--<div class="recent-job">
			<div class="container">
				<div class="row">
					
						 
					<div class="clearfix"></div>
				</div>
			</div>
		</div><!-- end Recent Job -->
		
	<?php
	include"footer.php";
	?>