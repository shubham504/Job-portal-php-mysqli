<?php
include"header.php";
include"config.php";
?>
		<div class="main-page-title"><!-- start main page title -->
			<div class="container">
				<div class="post-job-title">Create Your Profile To Post a Job</div>
				<div class="post-job-phone">Call: 1 800 000 500</div>
			</div>
		</div><!-- end main page title -->
		<div class="container">
		<div class="spacer-1">&nbsp;</div>
			<div class="row">
				<div class="col-md-8">
					
									<?php $sql=mysql_query("select* from job_post order by ID desc LIMIT 6");
while($row=mysql_fetch_array($sql))
{ echo"$row[title]";}?>
					<div class="spacer-2">&nbsp;</div>
				</div>
				
				<div class="col-md-4">
					<div class="job-side-wrap">
					<form method="post" action=""> 
						<h4>Employeer Zone <br>Login Here </h4>
					<p align="center">
						<input type="text" name="email" placeholder="Email" style="width:80%;height:40px;border-radius:3px;border:solid 1px;padding:2px 10px;" required>
						</p>
						<p align="center">
						<input type="password" name="password" placeholder="*******"  style="width:80%;height:40px;border-radius:3px;border:solid 1px;padding:2px 10px;" required>
						</p>
						
						<p ><input type="submit" value="LOG IN"  name="login" style="width:80%; height:36px;background:#1abc9c;border-radius:3px;border:none;color:#fff;"></p>
					</form>
					<p style="color:red"><?php
					if(isset($_POST['login']))
					{
						echo $msg;
					}
					?></p>
						</div>

					

				<img src="images/Login-screen.GIF" height="300">
				
				</div>
				<div class="col-md-4" style="background:url('images/Login-screen.GIF') no-reapet;"></div>
				</div>
		</div>

		<div id="page-content"><!-- start content -->
			<div class="content-about">
				<div id="cs"><!-- CS -->
					<div class="container">
					<div class="spacer-1">&nbsp;</div>
						<h1>Hey Friends Any Quries?</h1>
						<p>
							At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt.
						</p>
						<h1 class="phone-cs">Call: 1 800 000 500</h1>
					</div>
				</div><!-- CS -->
			</div><!-- end content -->
		</div><!-- end page content -->
<?php
include"footer.php";
?>