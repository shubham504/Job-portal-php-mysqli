<?php
include"header.php"";

include"config.php"";
if(isset($_POST['register']))
{
	
	$mail=$_POST['mail'];
	
	$pass=$_POST['password'];
	
	$name=$_POST['company'];
	
	$phone=$_POST['contact'];
	
	$add=$_POST['address'];
	$city=$_POST['city'];
	
	$state=$_POST['state'];
	
	$zip=$_POST['zip'];
	$sql=mysql_query("select * from employeer where user_email='$mail'");
	if($row=mysql_fetch_array($sql)){
	$msg1="Email Already Exists! Please Choose another Email";
	}
	else{
	$sql=mysql_query("insert into employeer (user_email,password,company,contact,address,city,state,zip) values('$mail',md5('$pass'),'$name','$phone','$add','$city','$state','$zip')");
	$msg1="You have Successfully Register With Job in Agri Please Login To Post a Job";
	}
}
if(isset($_POST['login']))
	
{
	$user=$_POST['email'];
	$pass=$_POST['password'];
	$sql=mysql_query("select * from employeer where user_email='$user' and password=md5('$pass')");
	if($row=mysql_fetch_array($sql))
	{
		$_SESSION['user']=$user;
		$_SESSION['user_password']=$pass;
		
		echo"<script>window.location='employeerzone/'</script>";
		
	}
	else{
		$msg="Invalid Email or Password ! Please Try Again with Valid Email and Password";
	}
}
?>
		<div class="main-page-title"><!-- start main page title -->
			<div class="container">
				<div class="post-job-title">Create Your Profile To Post a Job</div>
				<div class="post-job-phone">Call: 1 800 000 500</div>
			</div>
		</div><!-- end main page title -->
		<div class="container">
		<div class="spacer-1">&nbsp;</div>
			<div class="row">
				<div class="col-md-8">
					<form role="form" class="post-job-form" method="post" action="">
						<div class="form-group">
							<label for="email">Your Email</label>
							<input type="text" class="form-control input" id="email" name="mail" required/>
						</div>
						<div class="form-group">
							<label for="jobtitle">Password</label>
							<input type="password" class="form-control input" id="jobtitle" name="password" required />
						</div>

						<div class="form-group">
							<label for="joblocation">Company Name </label>
							<input type="text" class="form-control input" id="joblocation" name="company" required />
							
						</div>


						
					<div class="form-group">
							<label for="appemail">Contact No </label>
							<input type="text" class="form-control input" id="appemail" name="contact" required/>
						</div>


						
							<div class="form-group">
								<label for="companyname">Address</label>
								<input type="text" class="form-control input" id="companyname" name="address" required />
							</div>

							<div class="form-group">
								<label for="tagline">City</label>
								<input type="text" class="form-control input" id="tagline" name="city" />
							</div>
						
							<div class="form-group">
								<label for="tagline">State</label>
								<select name="state" class="form-control input"><option>----Select a State ------</option>
								<option value="Andhra Pradesh"> Andhra Pradesh </option>
								<option value="Arunachal Pradesh"> Arunachal Pradesh</option>
								<option value="Assam">Assam</option>
								<option value="Bihar"> Bihar</option>
								<option value="Chhattisgarh"> Chhattisgarh</option>
								<option value="Goa"> Goa</option>
								<option value="Gujarat"> Gujarat</option>
								<option value="Haryana"> Haryana</option>
								<option value="Himachal Pradesh"> Himachal Pradesh</option>
								<option value="Jammu & Kashmir"> Jammu & Kashmir</option>
								<option value="Jharkhand">Jharkhand</option>
								<option value="Karnataka"> Karnataka</option>
								<option value="Kerala"> Kerala</option>
								<option value="Madhya Pradesh"> Madhya Pradesh</option>
								<option value="Maharashtra"> Maharashtra</option>
								<option value="Manipur"> Manipur</option>
								<option value="Meghalaya"> Meghalaya</option>
								<option value="Mizoram"> Mizoram</option>
								<option value="Nagaland"> Nagaland</option>
								<option value="Odisha "> Odisha </option>
								<option value="Punjab"> Punjab</option>
								<option value="Rajasthan"> Rajasthan</option>
								<option value="Sikkim"> Sikkim</option>
								<option value="Tamil Nadu"> Tamil Nadu</option>
								<option value="Telangana"> Telangana</option>
								<option value="Tripura">Tripura</option>
								<option value="Uttar Pradesh">Uttar Pradesh</option>
								<option value="Uttarakhand">Uttarakhand</option>
								
								</select>
								</div>
							<div class="form-group">
								<label for="tagline">Zip Code</label>
								<input type="text" class="form-control input" id="tagline" name="zip" />
							</div>
						<div class="row">
							
							
							<div class="clearfix"></div>
							
						</div>

						
						<div class="form-group">
							<input type="submit" name="register" class="btn btn-default btn-green" value="Create Account">
						</div>
					</form>
					
					<p style="color:red"><?php
					if(isset($_POST['register']))
					{
						echo $msg1;
					}
					?></p>
					<div class="spacer-2">&nbsp;</div>
				</div>
				
				<div class="col-md-4">
					<div class="job-side-wrap">
					<form method="post" action=""> 
						<h4>Employeer Zone <br>Login Here </h4>
					<p align="center">
						<input type="text" name="email" placeholder="Email" style="width:80%;height:40px;border-radius:3px;border:solid 1px;padding:2px 10px;" required>
						</p>
						<p align="center">
						<input type="password" name="password" placeholder="*******"  style="width:80%;height:40px;border-radius:3px;border:solid 1px;padding:2px 10px;" required>
						</p>
						
						<p ><input type="submit" value="LOG IN"  name="login" style="width:80%; height:36px;background:#1abc9c;border-radius:3px;border:none;color:#fff;"></p>
					</form>
					<p style="color:red"><?php
					if(isset($_POST['login']))
					{
						echo $msg;
					}
					?></p>
						</div>

					

				<img src="images/Login-screen.GIF" height="300">
				
				</div>
				<div class="col-md-4" style="background:url('images/Login-screen.GIF') no-reapet;"></div>
				</div>
		</div>

		<div id="page-content"><!-- start content -->
			<div class="content-about">
				<div id="cs"><!-- CS -->
					<div class="container">
					<div class="spacer-1">&nbsp;</div>
						<h1>Hey Friends Any Quries?</h1>
						<p>
							At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt.
						</p>
						<h1 class="phone-cs">Call: 1 800 000 500</h1>
					</div>
				</div><!-- CS -->
			</div><!-- end content -->
		</div><!-- end page content -->
