<?php
include"config.php";
include"header.php";


if(isset($_POST['register']))
{
	
	$mail=$_POST['mail'];
	
	$pass=$_POST['password'];
	
	$name=$_POST['company'];
	
	$phone=$_POST['contact'];
	
	$add=$_POST['address'];
	$city=$_POST['city'];
	
	$state=$_POST['state'];
	$date=date("jS\ F Y");
	$zip=$_POST['zip'];
	$sql=mysql_query("select * from employeer where user_email='$mail'");
	if($row=mysql_fetch_array($sql)){
	$msg1="Error : Email Already Exists! Please Choose another Email";
	}
	else{
	$sql=mysql_query("insert into employeer (user_email,password,company,contact,address,city,state,zip,reg_date) values('$mail',md5('$pass'),'$name','$phone','$add','$city','$state','$zip','$date')");
	$msg1="You have Successfully Register With JobinAgri Please Login To Post a Job";
	}
}
if(isset($_POST['emplogin']))
	
{
	$user=$_POST['email'];
	$pass=$_POST['password'];
	$sql=mysql_query("select * from employeer where user_email='$user' and password=md5('$pass')");
	if($row=mysql_fetch_array($sql))
	{
		$_SESSION['user']=$user;
		$_SESSION['user_password']=$pass;
		
		echo"<script>window.location='Employeerzone/'</script>";
		
	}
	else{
		$msg="Error : Invalid Email or Password ";
	}
}
?>
		<div class="main-page-title"><!-- start main page title -->
			<div class="container">
				<div class="post-job-title">Create Your Profile To Post a Job</div>
			</div>
		</div><!-- end main page title -->
		<div class="container">
		<div class="spacer-1">&nbsp;</div>
			<div class="row">
				<div class="col-md-9">
				
					<?php
					if(isset($_POST['register']))
					{
						echo "<p style='color:red;font-family: initial;'>$msg1</p>";
					}
					?>
					<form role="form" class="post-job-form" method="post" action="">
						<div class="form-group">
							<label for="email">Your Email</label>
							<input type="email" class="form-control input" id="email" name="mail" required/>
						</div>
						<div class="form-group">
							<label for="jobtitle">Password</label>
							<input type="password" class="form-control input" id="jobtitle" minlength="8" name="password" required />
						</div>

						<div class="form-group">
							<label for="joblocation">Company Name </label>
							<input type="text" class="form-control input" id="joblocation" name="company" required />
							
						</div>


						
					<div class="form-group">
							<label for="appemail">Contact No </label>
							<input type="text" class="form-control input" maxlength="10" minlength="10" id="appemail" name="contact" required/>
						</div>


						
							<div class="form-group">
								<label for="companyname">Address</label>
								<input type="text" class="form-control input" id="companyname" name="address" required />
							</div>

							<div class="form-group">
								<label for="tagline">City</label>
								<input type="text" class="form-control input" id="tagline" name="city"  required/>
							</div>
						
							<div class="form-group">
								<label for="tagline">State</label>
								<select name="state" class="form-control input" required><option>----Select a State ------</option>
								<option value="Andhra Pradesh"> Andhra Pradesh </option>
								<option value="Arunachal Pradesh"> Arunachal Pradesh</option>
								<option value="Assam">Assam</option>
								<option value="Bihar"> Bihar</option>
								<option value="Chhattisgarh"> Chhattisgarh</option>
								<option value="Goa"> Goa</option>
								<option value="Gujarat"> Gujarat</option>
								<option value="Haryana"> Haryana</option>
								<option value="Himachal Pradesh"> Himachal Pradesh</option>
								<option value="Jammu & Kashmir"> Jammu & Kashmir</option>
								<option value="Jharkhand">Jharkhand</option>
								<option value="Karnataka"> Karnataka</option>
								<option value="Kerala"> Kerala</option>
								<option value="Madhya Pradesh"> Madhya Pradesh</option>
								<option value="Maharashtra"> Maharashtra</option>
								<option value="Manipur"> Manipur</option>
								<option value="Meghalaya"> Meghalaya</option>
								<option value="Mizoram"> Mizoram</option>
								<option value="Nagaland"> Nagaland</option>
								<option value="Odisha "> Odisha </option>
								<option value="Punjab"> Punjab</option>
								<option value="Rajasthan"> Rajasthan</option>
								<option value="Sikkim"> Sikkim</option>
								<option value="Tamil Nadu"> Tamil Nadu</option>
								<option value="Telangana"> Telangana</option>
								<option value="Tripura">Tripura</option>
								<option value="Uttar Pradesh">Uttar Pradesh</option>
								<option value="Uttarakhand">Uttarakhand</option>
								
								</select>
								</div>
							<div class="form-group">
								<label for="tagline">Zip Code</label>
								<input type="text" class="form-control input" id="tagline" maxlength="6" name="zip" required />
							</div>
						<div class="row">
							
							
							<div class="clearfix"></div>
							
						</div>

						
						<div class="form-group">
							<input type="submit" name="register" class="btn btn-default btn-blue" value="Create Account">
						</div>
					</form>
					
					<div class="spacer-2">&nbsp;</div>
				</div>
				
				<div class="col-md-3">
					<div class="job-side-wrap">
					<form method="post" action=""> 
						<h4>Employer Zone </h4>
					<p align="center">
						<input type="text" name="email" placeholder="Email" style="width:96%;height:33px;border-radius:3px;border:solid 1px;padding:2px 10px;" required>
						</p>
						<p align="center">
						<input type="password" name="password" placeholder="*******"  style="width:96%;height:33px;border-radius:3px;border:solid 1px;padding:2px 10px;" required>
						</p>
						
						<p ><input type="submit" value="LOG IN"  name="emplogin" style="width:40%; height:36px;background:#49C30B;border-radius:3px;border:none;color:#fff;"></p>
					</form>
					<p align="center"><a href="emp_forgot.php" target=_blank>Forgot Password</p>
					<?php
					if(isset($_POST['emplogin']))
					{
						echo"<p style='color:red'>$msg</p>";
					}
					?>
					
						</div>

					

				
				</div>
				<div class="col-md-4" style="background:url('images/Login-screen.GIF') no-reapet;"></div>
				</div>
		</div>

<?php
include"footer.php";
?>