<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Job Board</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<!-- Bootstrap -->

	<!-- Main Style -->
    <link href="css/style.css" rel="stylesheet">
	<link href="css/changepas.css" rel="stylesheet" type="text/css">
	

    <link href='http://fonts.googleapis.com/css?family=Nunito:300,400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,300,500,600,700' rel='stylesheet' type='text/css'>
	<link href='css/font-awesome.css' rel="stylesheet" type="text/css">
	<link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">
	<link href="css/owl.transitions.css" rel="stylesheet">
<link rel="stylesheet" href="css/jslider.css" type="text/css">
	<link rel="stylesheet" href="css/jslider.round.css" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript">
$('document').ready(function(){
	$('#sign-in-form').submit(function (e) {
	
 e.preventDefault(); //prevent default form gh
 
 $.ajax({
     type: "POST",
     url: 'submit.php',
     data: $('#sign-in-form').serialize(),
     dataType: 'json',
     error: function(a,b,c) {
      $("#signin-response").html("Unable to process request");
      $("#signin-response").addClass("alert alert-error text-center");
     },
     cache: false,
     success: function(msg){
      if(msg.success){
       $("#signin-response").addClass("alert-success");
       $("#signin-response").html(msg.success);
       location.href='seekers/';
      }
      if(msg.error){
       $("#signin-response").html(msg.error);
       $("#signin-response").addClass("alert-error");
       $('#sign-in-submit').html('Sign In');
       return false;
      } 
     }
   });
 }); 
 });
	</script>
	</head>
  <body>
	<div id="wrapper"><!-- start main wrapper -->
		<div id="header"><!-- start main header -->
			<div class="top-line">&nbsp;</div>
			<div class="top"><!-- top -->
				<div class="container">
					<div class="media-top-right">
						
						<ul class="media-top-2 clearfix">
							<li><a href="seeker_registration.php" class="btn btn-default btn-blue btn-sm">REGISTER</a></li>
							<li><a href="seeker_registration.php"  class="btn btn-default btn-green btn-sm" >LOG IN</a></li>
							<li><a href="employeerZone.php"  class="" >Employer Zone </a></li>
						
						</ul>
						<div class="clearfix"></div>
						
					</div>
					</div>
			</div>

			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<a href="index.php" title="Job Board" rel="home">
							<img class="main-logo" src="images/logo.png" alt="job board" />
						</a>
					</div>
					<div class="col-md-8 main-nav"><!-- Main Navigation -->
						<a id="touch-menu" class="mobile-menu" href="#"><i class="fa fa-bars fa-2x"></i></a>
						<nav>
							<ul class="menu">
								<li><a href="index.php">HOME</a>
									
								</li>
								<li><a  href="employeerZone.php">POST A JOB</a></li>
								<li><a  href="seeker_registration.php">POST A RESUME</a></li>
								
								
								<li><a  href="services.php">SERVICES</a></li>
                                <li><a  href="contact.php">CONTACT US</a></li>
															
							</ul>
						</nav>
					</div><!-- Main Navigation -->
					<div class="clearfix"></div>
				</div>
			</div><!-- container -->
		</div><!-- end main header -->
	<div class="cd-popup" role="alert">
	
	<div class="cd-popup-container" id="act">
		<p>Job Seekers</p>
		<form action="#" method="post" id="sign-in-form">
<label>Email</label><input type="text" name="username" class="pop_login" required >

<label>Password </label><input type="password" name="password" class="pop_login" required>

<input type="submit" name="skrlogin" value="Log In">
</form>
	<a href="#0" class="cd-popup-close img-replace">Close</a>
<div id="signin-response" class=""></div>

		<p style="margin:top:-40px !important;"> <a href="seeker_forgot.php"  target="_blank">forgot password ?</a>
		<br>New User <a href="seeker_registration.php" >Register Here</a></p>

	</div>
	
</div> 
	
	