<?php include"config.php"; ?>
<?php
	include"header.php";
			?>

			<div class="main-slider">
				<div id="home-slider" class="owl-carousel owl-theme">
					<div class="item-slide">
					
						<img src="images/dummy-slide-1.jpg" class="img-responsive" alt="dummy-slide" />
					</div>
					<div class="item-slide">
						<img src="images/dummy-slide-2.jpg" class="img-responsive" alt="dummy-slide" />
					</div>
				</div>
			</div>

			<div class="headline container">
					<div class="row" >

<p align="center" style="font-size:25px;color:#fff">Everything About Your Career at JobsInAgri.com</p>
					<div class="searchbar">
						<form action="search.php" method="get">
								
						
						<input type="text" id="searchjob" name="keyword"class="top_search"  placeholder="Keywords(Enter Skills, Designation, etc) ">
						<input type="text" id="searchplace" name="location" class="top_search1" placeholder="Location">
					<select class="top_search1"  name="experience">
					<option >   Experience</option>
					<option value="0">Entry Level</option>
<option value="1">1 year</option>
<option value="2">2 years</option>
<option value="3">3 years</option>
<option value="4">4 years</option>
<option value="5">5 years</option>
<option value="6">6 years</option>
<option value="7">7 years</option>
<option value="8">8 years</option>
<option value="9">9 years</option>
<option value="10">10 years</option>
<option value="11">11 years</option>
<option value="12">12 years</option>
<option value="13">13 years</option>
<option value="14">14 years</option>
<option value="15">15 years</option>
<option value="16">16 years</option>
<option value="17">17 years</option>
<option value="18">18 years</option>
<option value="19">19 years</option>
<option value="20">20 years</option>
<option value="21">20+ years</option>
					</select>
					<input type="submit" value="Search" class="search_top" name="search">
				</form>
						<div class="clearfix"></div>
					</div>
					</div>
			</div>
	
		
		<div class="recent-job">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<h4> Latest  Jobs in Agriculture</h4>
						<div id="tab-container" class='tab-container'><!-- Start Tabs -->
							<ul class='etabs clearfix'>
								<li class='tab'><a href="#all">All</a></li>
								
							</ul>
							<div class='panel-container'>
								<div id="all"><!-- Tabs section 1 -->
								
									
									<?php $sql=mysql_query("select* from job_post where approvel='1' order by ID desc LIMIT 10");
while($row=mysql_fetch_array($sql))
{ ?>
									<div class="recent-job-list-home"><!-- Tabs content -->
										<div class="job-list-logo col-md-1 ">
										<?php echo "<img src='Employeerzone/logo/$row[logo]' class='img-responsive' alt='dummy-joblist' />";?>
										</div>
										<div class="col-md-6 job-list-desc">
											<h6><?php echo $row['title']; ?> (<?php echo $row['min_experience']." -".$row['max_experience']."  Yrs";?>)</h6>
											<p><img src="images/company.png" width="14px" title="company name"> - <?php echo $row['company'];?></p>
											<p class="location"><img src="images/location.png" width="14px" title="Job Location"> -  <?php echo $row['location'];?> </p>
											<p><img src="images/education.png" width="14px" title="Qualification"> - <?php echo $row['qualification'];?> </p>
											  <br>
											<p class="location"><img src="images/rupees.png" width="14px" title="Salary per Annum"> - <?php echo $row['salary'];?> &nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; <img src="images/area.png" width="14px" title="Functional area"> - <?php echo $row['category'];?> <a href="#0" class="cd-popup-trigger">Apply Now</a></p>
											
											
											
        									<p class="location"></p>
											
			
										</div>
									
										<div class="clearfix"></div>
									</div><!-- Tabs content -->
									<?php }?>
									
									<center><h5><a href="#0" class="cd-popup-trigger">SEE MORE</a></h5></center>
								</div>
								<div id="contract">
									 
									
								</div><!-- Tabs section 2 -->
								<div id="full"><!-- Tabs section 3 -->

									
								</div><!-- Tabs section 3 -->
								<div id="free"><!-- Tabs section 4 -->
								
									

								</div><!-- Tabs section 4 -->
						 
							</div>
						</div><!-- end Tabs -->
						<div class="spacer-2"></div>
					</div>

					<div class="col-md-4">
						<div id="job-opening">
							<div class="job-opening-top">
								<div class="job-oppening-title">Urgent Requirement</div>
								<div class="job-opening-nav">
									<a class="btn prev"></a>
									<a class="btn next"></a>
									<div class="clearfix"></div>
								</div>
							</div>
							<div class="clearfix"></div>
							<br/>
							
							<div id="job-opening-carousel" class="owl-carousel">
<?php
							$sql=mysql_query("select * from job_post where hot_job='1' and approvel='1'");
							while($row=mysql_fetch_array($sql))
							{
								 $logo="Employeerzone/logo/$row[logo]";
							?>							
								<div class="item-home">
									<div class="job-opening">
										<img src="<?php echo $logo;?>" class="img-responsive" alt="dummy-job-opening" />
										
										<div class="job-opening-content">
											<?php echo $row['title'];?>
											<p>
												<?php
                                            $dis=$row['jobdiscription'];
                                             $detail=substr($dis,0,150);												
												echo $detail;?>
											</p>
										</div>
										
										<div class="job-opening-meta clearfix">
											<div class="meta-job-location meta-block"><i class="fa fa-map-marker"></i><?php echo $row['location'];?></div>
											<div class="meta-job-type meta-block"><i class="fa fa-user"></i><a href="#0" class="cd-popup-trigger">Apply Here</a></div>
										</div>
									</div>
								</div>
							
								
							<?php }?>	
							</div>
							
						</div>

						
					</div>
					<div class="col-md-4" >
						<p style="font-size:20px;">Recent Agri News</p>
						<div id="job-opening"style='border:solid 1px #eee'>
						
							<marquee id="scroll_news" direction="up" scrolldelay="300" style="height: 250px;" height="250px">
			<div onmouseover="document.getElementById('scroll_news').stop();" onmouseout="document.getElementById('scroll_news').start();">
			<p style="padding-top:5px;padding-right:15px;padding-bottom:5px;padding-left:15px;"> <a href="http://foodtank.com/?gclid=CJeD5ej6yMgCFVYrjgodRDAHCw">Food Tank would love the opportunity to see what you’re harvesting in your backyard, in pots, in your community garden, or on your roof!</a></p>
 </div> </marquee>
							</div>
							
						</div>

						
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div><!-- end Recent Job -->
		<div class="job-status">
			<div class="container">
					<h1>Jobs Stats Updates</h1>
					
					<div class="counter clearfix">
					<div class="counter-container">
							<div class="counter-value">35</div>
							<div class="line"></div>
							<p>Job Posted</p>
						</div>
						<div class="counter-container">
							<div class="counter-value">6</div>
							<div class="line"></div>
							<p>Live Jobs</p>
						</div>
			
						
						<div class="counter-container">
							<div class="counter-value">18</div>
							<div class="line"></div>
							<p>possition Filled</p>
						</div>
						
						<div class="counter-container">
							<div class="counter-value">5</div>
							<div class="line"></div>
							<p>Companies</p>
						</div>
						
						<div class="counter-container">
							<div class="counter-value">250</div>
							<div class="line"></div>
							<p>Members</p>
						</div>
						
					</div>
				
			</div>
		</div>
		<div class="step-to">
			<div class="container">
				<h1>Easiest Way To Use</h1>
				<p>
					Follow the Steps and use our Services.
					</p>
	
				<div class="step-spacer"></div>
				<div id="step-image">
					<div class="step-by-container">
						<div class="step-by">
							First Step
							<div class="step-by-inner">
								<div class="step-by-inner-img">
									<img src="images/step-icon-1.png" alt="step" />
								</div>
							</div>
							<h5>Register with us</h5>
						</div>
								
						<div class="step-by">
							Second Step
							<div class="step-by-inner">
								<div class="step-by-inner-img">
									<img src="images/step-icon-2.png" alt="step" />
								</div>
							</div>
							<h5>Create your profile</h5>
						</div>
								
						<div class="step-by">
							Third Step
							<div class="step-by-inner">
								<div class="step-by-inner-img">
									<img src="images/step-icon-3.png" alt="step" />
								</div>
							</div>
							<h5>Upload your resume</h5>
						</div>
								
						<div class="step-by">
							Now it's our turn
							<div class="step-by-inner">
								<div class="step-by-inner-img">
									<img src="images/step-icon-4.png" alt="step" />
								</div>
							</div>
							<h5>Now take rest :)</h5>
						</div>
								
					</div>
				</div>
				<div class="step-spacer"></div>
			</div>
		</div>
		<!--<div class="testimony">
			<div class="container">
				<h1>What People Say About Us</h1>
				<p>
					At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas mo
				</p>
					
			</div>
			<div id="sync2" class="owl-carousel">
				<div class="testimony-image">
					<img src="images/testimony-image-1.jpg" class="img-responsive" alt="testimony"/>
				</div>
				<div class="testimony-image">
					<img src="images/testimony-image-2.jpg" class="img-responsive" alt="testimony"/>
				</div>
				<div class="testimony-image">
					<img src="images/testimony-image-3.jpg" class="img-responsive" alt="testimony"/>
				</div>
				<div class="testimony-image">
					<img src="images/testimony-image-4.jpg" class="img-responsive" alt="testimony"/>
				</div>
				<div class="testimony-image">
					<img src="images/testimony-image-5.jpg" class="img-responsive" alt="testimony"/>
				</div>
				<div class="testimony-image">
					<img src="images/testimony-image-6.jpg" class="img-responsive" alt="testimony"/>
				</div>
				<div class="testimony-image">
					<img src="images/testimony-image-7.jpg" class="img-responsive" alt="testimony"/>
				</div>
				<div class="testimony-image">
					<img src="images/testimony-image-8.jpg" class="img-responsive" alt="testimony"/>
				</div>
				<div class="testimony-image">
					<img src="images/testimony-image-9.jpg" class="img-responsive" alt="testimony"/>
				</div>
				<div class="testimony-image">
					<img src="images/testimony-image-10.jpg" class="img-responsive" alt="testimony"/>
				</div>
				
			</div>
			
			<div id="sync1" class="owl-carousel">
				<div class="testimony-content container">
					<p>
						"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum .
						
					</p>
					<p>
						John Grasin, CEO, IT-Planet
					</p>
					<div class="media-testimony">
						<a href="" target="blank"><i class="fa fa-twitter twit"></i></a>
						<a href="" target="blank"><i class="fa fa-linkedin linkedin"></i></a>
						<a href="" target="blank"><i class="fa fa-facebook fb"></i></a>
					</div>
				</div>
				<div class="testimony-content container">
					<p>
						"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum .
						
					</p>
					<p>
						John Grasin, CEO, IT-Planet
					</p>
					<div class="media-testimony">
						<a href="" target="blank"><i class="fa fa-twitter twit"></i></a>
						<a href="" target="blank"><i class="fa fa-linkedin linkedin"></i></a>
						<a href="" target="blank"><i class="fa fa-facebook fb"></i></a>
					</div>
				</div>
				<div class="testimony-content container">
					<p>
						"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum .
						
					</p>
					<p>
						John Grasin, CEO, IT-Planet
					</p>
					<div class="media-testimony">
						<a href="" target="blank"><i class="fa fa-twitter twit"></i></a>
						<a href="" target="blank"><i class="fa fa-linkedin linkedin"></i></a>
						<a href="" target="blank"><i class="fa fa-facebook fb"></i></a>
					</div>
				</div>
				<div class="testimony-content container">
					<p>
						"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum .
						
					</p>
					<p>
						John Grasin, CEO, IT-Planet
					</p>
					<div class="media-testimony">
						<a href="" target="blank"><i class="fa fa-twitter twit"></i></a>
						<a href="" target="blank"><i class="fa fa-linkedin linkedin"></i></a>
						<a href="" target="blank"><i class="fa fa-facebook fb"></i></a>
					</div>
				</div>
				<div class="testimony-content container">
					<p>
						"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia.
						
					</p>
					<p>
						John Grasin, CEO, IT-Planet
					</p>
					<div class="media-testimony">
						<a href="" target="blank"><i class="fa fa-twitter twit"></i></a>
						<a href="" target="blank"><i class="fa fa-linkedin linkedin"></i></a>
						<a href="" target="blank"><i class="fa fa-facebook fb"></i></a>
					</div>
				</div>
				<div class="testimony-content container">
					<p>
						"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate.
						
					</p>
					<p>
						John Grasin, CEO, IT-Planet
					</p>
					<div class="media-testimony">
						<a href="" target="blank"><i class="fa fa-twitter twit"></i></a>
						<a href="" target="blank"><i class="fa fa-linkedin linkedin"></i></a>
						<a href="" target="blank"><i class="fa fa-facebook fb"></i></a>
					</div>
				</div>
				<div class="testimony-content container">
					<p>
						"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum .
						
					</p>
					<p>
						John Grasin, CEO, IT-Planet
					</p>
					<div class="media-testimony">
						<a href="" target="blank"><i class="fa fa-twitter twit"></i></a>
						<a href="" target="blank"><i class="fa fa-linkedin linkedin"></i></a>
						<a href="" target="blank"><i class="fa fa-facebook fb"></i></a>
					</div>
				</div>
				<div class="testimony-content container">
					<p>
						"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum . At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum .
						
					</p>
					<p>
						John Grasin, CEO, IT-Planet
					</p>
					<div class="media-testimony">
						<a href="" target="blank"><i class="fa fa-twitter twit"></i></a>
						<a href="" target="blank"><i class="fa fa-linkedin linkedin"></i></a>
						<a href="" target="blank"><i class="fa fa-facebook fb"></i></a>
					</div>
				</div>
				<div class="testimony-content container">
					<p>
						"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti.	
					</p>
					<p>
						John Grasin, CEO, IT-Planet
					</p>
					<div class="media-testimony">
						<a href="" target="blank"><i class="fa fa-twitter twit"></i></a>
						<a href="" target="blank"><i class="fa fa-linkedin linkedin"></i></a>
						<a href="" target="blank"><i class="fa fa-facebook fb"></i></a>
					</div>
				</div>
				<div class="testimony-content container">
					<p>
						"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.
						
					</p>
					<p>
						John Grasin, CEO, IT-Planet
					</p>
					<div class="media-testimony">
						<a href="" target="blank"><i class="fa fa-twitter twit"></i></a>
						<a href="" target="blank"><i class="fa fa-linkedin linkedin"></i></a>
						<a href="" target="blank"><i class="fa fa-facebook fb"></i></a>
					</div>
				</div>
			</div>
		</div> -->
		
	<!--	<div id="company-post">
			<div class="container">
				
				<h1>Companies Who Have Posted Jobs</h1>
				<p>
					At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi.
				</p>
					
				<div id="company-post-list" class="owl-carousel company-post">
					<div class="company">
						<img src="images/company-1.png" class="img-responsive" alt="company-post" />
					</div>
					<div class="company">
						<img src="images/company-2.png" class="img-responsive" alt="company-post" />
					</div>
					<div class="company">
						<img src="images/company-3.png" class="img-responsive" alt="company-post" />
					</div>
					<div class="company">
						<img src="images/company-4.png" class="img-responsive" alt="company-post" />
					</div>
					<div class="company">
						<img src="images/company-5.png" class="img-responsive" alt="company-post" />
					</div>
					
					<div class="company">
						<img src="images/company-1.png" class="img-responsive" alt="company-post" />
					</div>
					<div class="company">
						<img src="images/company-2.png" class="img-responsive" alt="company-post" />
					</div>
					<div class="company">
						<img src="images/company-3.png" class="img-responsive" alt="company-post" />
					</div>
					<div class="company">
						<img src="images/company-4.png" class="img-responsive" alt="company-post" />
					</div>
					<div class="company">
						<img src="images/company-5.png" class="img-responsive" alt="company-post" />
					</div>
					
				</div>
			</div>
		</div>-->

	<?php
	include"footer.php";
	?>