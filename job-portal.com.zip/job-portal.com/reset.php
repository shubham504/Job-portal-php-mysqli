<?php include('config.php');
 $iddd=$_GET['encrypt'];
if(isset($_POST['resetpass']))
{          
$npass=$_POST['npass'];
$cpass=$_POST['cpass'];
        $query = mysql_query("SELECT * FROM jobseekers where reset='$iddd'");
        
        
        if($row = mysql_fetch_array($query))
        {
        $mail=$row['email'];
       
        if($npass==$cpass)
        {
        $query1 = mysql_query("update jobseekers set password=md5('$npass') where reset='$iddd' AND email='$mail'");  
        if($query1)
        {
        $query = mysql_query("update jobseekers set reset='0' where email='$mail'");  
        
        $msg="Password Reset Successfully";      
        }
        }
    else{
       $msg="Error : Password are not Same";
    
    }
        }
        else
        {
            $msg = 'Error : Link has been Expired';
        }
    }
?>

<html><head>
<title>
Jobs in Agri
</title>

<style>
.form{
width: 30%;
    float: left;
    margin-left: 35%;
    background: whitesmoke;
    margin-top: 170px;
    border-radius:6px;
.form-group{
width: 90%;
    float: left;
    margin-left: 5%;
    margin-top: 20px;
    }
   
 h2
{
width:100%;
text-align:center;
background-color:#F75900 !important;  
}
p{
width:100%;
}
</style>
</head>
<div class="form">
<form action="#" method="post">

<h2 style="background: #F75900;
    height: 35px;
    margin-top: 0px;
    text-align: center;
    padding-top: 7px;
    color: #fff;
    text-transform: uppercase;
    border-top-right-radius: 6px;
    border-top-left-radius: 6px;"> Jobsinagri.com</h2>
    <div class="form-group">
        <label style="width: 80%;float: left;margin-left: 10%;font-size:23px;color:#a3a3a3">Reset Your Password</label>
        <input type="password" placeholder=" New Password" name="npass" style="width: 80%;float: left;margin-left: 10%; height:40px;border:solid 1px #eee;border-radius:2px;font-size:18px" />
      <input type="password" placeholder=" Confirm Password" name="cpass" style="width: 80%;float: left;margin-left: 10%; height:40px;border:solid 1px #eee;border-radius:2px;font-size:18px" />
    
    <input type="submit" value="SUBMIT" name="resetpass" style="width: 40%;float: left;margin-left: 30%;font-size:20px;color:#fff;background:#49C30B;border: none;
    border-radius: 5px;
    padding: 7px;
    margin-top: 20px;margin-bottom: 20px;  ">
    </form>
    <?php 
    if(isset($_POST['resetpass']))
    {
    echo"<p style='width:100%;text-align:center;color:red; float:left;'> $msg</p>";
    
    }
    ?>
    
    </div>