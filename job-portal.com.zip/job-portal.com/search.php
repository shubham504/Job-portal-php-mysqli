<?php
include"config.php";
			include"header.php";
			?>

		
		<div class="recent-job">
			<div class="container">
				<div class="row">
<div class="col-md-12" style="background-color:#000;opacity:.9;padding:40px 9%;border-radius:5px;">
			<form method="get" action="">
								
						
						<input type="text" id="searchjob" name="keyword" class="top_search"  placeholder="Keywords(Enter Skills, Designation, etc) ">
						<input type="text" id="searchplace"  name="location" class="top_search1" placeholder="Location">
					<select class="top_search1" name="experience" ><option selected>Experience</option>
					<option value="0">Entry Level</option>
<option value="1">1 year</option>
<option value="2">2 years</option>
<option value="3">3 years</option>
<option value="4">4 years</option>
<option value="5">5 years</option>
<option value="6">6 years</option>
<option value="7">7 years</option>
<option value="8">8 years</option>
<option value="9">9 years</option>
<option value="10">10 years</option>
<option value="11">11 years</option>
<option value="12">12 years</option>
<option value="13">13 years</option>
<option value="14">14 years</option>
<option value="15">15 years</option>
<option value="16">16 years</option>
<option value="17">17 years</option>
<option value="18">18 years</option>
<option value="19">19 years</option>
<option value="20">20 years</option>
<option value="21">20+ years</option>
					</select>
					<input type="submit" value="Search" class="search_top" name="search">
				</form>
				</div>
		
	<div class="col-md-9">
						<h4> Latest  Jobs in Agriculture </h4>
						<div id="tab-container" class='tab-container'><!-- Start Tabs -->
							<ul class='etabs clearfix'>
								<li class='tab'><a href="#all">All</a></li>
								
							</ul>
							<div class='panel-container'>
								<div id="all"><!-- Tabs section 1 -->
								
									
   
									<?php
									if(isset($_GET['search']))
 $word=$_GET['keyword'];
    $city=$_GET['location'];
    $exp=$_GET['experience'];
    
									$sql=mysql_query("select* from job_post WHERE (title LIKE '%".$word."%' OR category LIKE '%".$word."%' OR location='$city'
									OR (min_experience <='$exp' AND max_experience >='$exp')) AND approvel='1'  order by ID desc LIMIT 6");
while($row=mysql_fetch_array($sql))
{ ?>
									<div class="recent-job-list-home"><!-- Tabs content -->
										<div class="job-list-logo col-md-1 ">
										<?php echo "<img src='Employeerzone/logo/$row[logo]' class='img-responsive' alt='dummy-joblist' />";?>
										</div>
										<div class="col-md-6 job-list-desc">
											<h6><?php echo $row['title']; ?> (<?php echo $row['min_experience']." -".$row[max_experience]."  Yrs";?>)</h6>
											<p><img src="images/company.png" width="14px" title="company name"> - <?php echo $row['company'];?></p>
											<p class="location"><img src="images/location.png" width="14px" title="Job Location"> -  <?php echo $row['location'];?> </p>
											<p><img src="images/education.png" width="14px" title="Qualification"> - <?php echo $row['qualification'];?> </p>
											  <br>
											<p class="location"><img src="images/rupees.png" width="14px" title="Salary per Annum"> - <?php echo $row['salary'];?> &nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; <img src="images/area.png" width="14px" title="Functional area"> - <?php echo $row['category'];?><a href="#0" class="cd-popup-trigger">VIEW DETAILS </a></p>
											
			
										</div>
									
										<div class="clearfix"></div>
									</div><!-- Tabs content -->
									<?php }?>
									
									
									<center><h5><a href="#0" class="cd-popup-trigger">SEE MORE</a></h5></center>
								
								</div>
								<div id="contract">
									 
									
								</div><!-- Tabs section 2 -->
								<div id="full"><!-- Tabs section 3 -->

									
								</div><!-- Tabs section 3 -->
								<div id="free"><!-- Tabs section 4 -->
								
									

								</div><!-- Tabs section 4 -->
						 
							</div>
						</div><!-- end Tabs -->
						<div class="spacer-2"></div>
					</div>

					<div class="col-md-3">
						<div id="job-opening">
							<div class="job-opening-top">
								<div class="job-oppening-title">Top Job Opening</div>
								<div class="job-opening-nav">
									<a class="btn prev"></a>
									<a class="btn next"></a>
									<div class="clearfix"></div>
								</div>
							</div>
							<div class="clearfix"></div>
							<br/>
							
							<div id="job-opening-carousel" class="owl-carousel">
<?php
							$sql=mysql_query("select * from job_post where hot_job='1' AND approvel='1'");
							while($row=mysql_fetch_array($sql))
							{
								 $logo="Employeerzone/logo/$row[logo]";
							?>							
								<div class="item-home">
									<div class="job-opening">
										<img src="<?php echo $logo;?>" class="img-responsive" alt="dummy-job-opening" />
										
										<div class="job-opening-content">
											<?php echo $row['title'];?>
											<p>
												<?php
                                            $dis=$row['jobdiscription'];
                                             $detail=substr($dis,0,150);												
												echo $detail;?>
											</p>
										</div>
										
										<div class="job-opening-meta clearfix">
											<div class="meta-job-location meta-block"><i class="fa fa-map-marker"></i><?php echo $row['location'];?></div>
											<div class="meta-job-type meta-block"><i class="fa fa-user"></i><a href="#0" class="cd-popup-trigger">Apply Here</a></div>
										</div>
									</div>
								</div>
							
								
							<?php }?>	
							</div>
						</div>

						
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div><!-- end Recent Job -->
		
	<?php
	include"footer.php";
	?>