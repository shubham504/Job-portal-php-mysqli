<?php include"config.php";


include"header.php";
if(isset($_POST['register']))
{
	 $mail=$_POST['email'];
	 $name=$_POST['name'];
	  $password=$_POST['password'];
	  $ddd=$_POST['dobd'];	
	  $mmm=$_POST['dobm'];
	  $address=$_POST['per_add'];
	  $plocation=$_POST['pre_location'];
	  $ugg=$_POST['ug'];
	  $uguniv=$_POST['ug_university'];
	  $pgg=$_POST['pg'];
	  $pguniv=$_POST['pg_university'];
	  $cur_ctc=$_POST['current_ctc'];
	  $expcted=$_POST['exp_ctc'];
	 $c_com=$_POST['current_company'];
	  $lan1=$_POST['lan1'];
	 $lan2=$_POST['lan2'];
	  $lan3=$_POST['lan3'];
	
	 $yyy=$_POST['doby'];
	 $location=$_POST['location'];
	 $mobile=$_POST['mobile'];
	 $fun_area=$_POST['funcionalarea'];
	 $skills=$_POST['skills'];
	 $exp=$_POST['experience'];
	 $file_name = $_FILES['resume']['name'];
	 $encoded_image = date("d-m-y").'_'.$file_name;
	 $date=date("l jS \ F Y h:i:s A");
	 $sql=mysql_query("select * from jobseekers where email='$mail'");
	if($row=mysql_fetch_array($sql)){
	$msg1="Error : Email Already Exists! Please Choose another Email";
	}
	else{
	
	$sql=mysql_query("insert into jobseekers (fullname, email, password, mobile, ug, ug_university, pg, pg_university, current_ctc, exp_ctc, 
	current_location, per_address, pre_location, current_company, experience, 
	keyskill, functional_area, lan1, lan2, lan3, resume, date, dob_m,dob_y,dob_d ) VALUES
	('$name','$mail',md5('$password'),'$mobile','$ugg','$uguniv','$pgg','$pguniv','$cur_ctc','$expcted','$location','$address','$plocation','$c_com','$exp','$skills','$fun_area','$lan1',
	'$lan2','$lan3','$encoded_image','$date','$mmm','$yyy','$ddd')");
move_uploaded_file($_FILES['resume']['tmp_name'],"resumes/".$encoded_image);
	 
	$msg1="Thank you for Registration on Jobs in Agri";
	}
}
if(isset($_POST['login']))
	
{
	$user=$_POST['email'];
	$pass=$_POST['password'];
	$sql=mysql_query("select * from jobseekers where email='$user' and password=md5('$pass')");
	if($row=mysql_fetch_array($sql))
	{
		$_SESSION['user']=$user;
		$_SESSION['user_password']=$pass;
		
		echo"<script>window.location='seekers/'</script>";
		
	}
	else{
		$msg="Error ! Invalid Email or Password !";
	}
}


?>
		<div class="main-page-title"><!-- start main page title -->
			<div class="container">
				<div class="post-job-title">Create your Profile</div>
				<div class="post-job-phone">Call: 0141 -3356493</div>
			</div>
		</div><!-- end main page title -->
		<div class="container">
		<div class="spacer-1">&nbsp;</div>
			<div class="row">
				<div class="col-md-9">
				<?php 
				if(isset($_POST['register']))
				{
					echo "<p style='color:red'>$msg1</p>";
				}
				?>
					<form role="form" class="post-job-form" method="post" action="" enctype="multipart/form-data">
						<div class="form-group">
							<label for="email">Your Email *</label>
							<input type="email" class="form-control input" id="email" name="email"  required/>
						</div>
						<div class="form-group">
							<label for="jobtitle">Full Name *</label>
							<input type="text" class="form-control input" id="jobtitle" name="name" required/>
						</div>

						<div class="form-group">
							<label for="joblocation">Choose a Password *</label>
							<input type="password" class="form-control input" id="joblocation" minlength="8" name="password" required />
							
						</div>
                          <div class="form-group">
								<label for="jobtype">Mobile No *</label>
							<input type="text" class="form-control input" id="joblocation" maxlength="10" minlength="10" name="mobile" required />
								</div>
						<div class="form-group">
								<label for="jobtype">Date of Birth *</label><br>
							<input type="text"   placeholder="  DD" name="dobd" required style="width:70px;border:1px solid #dee4e5; margin-right:10px;border-radius:4px; height:32px;"/>
							<input type="text"   name="dobm" placeholder=" MM" required style="width:70px;border:1px solid #dee4e5; margin-right:10px;border-radius:4px; height:32px;"/>
							
							<input type="text"  name="doby" required placeholder=" YYYY"style="width:100px;border:1px solid #dee4e5; margin-right:10px;border-radius:4px; height:32px;"/>
								</div>
						
							<div class="form-group">
								<label for="jobtype">Current Location *</label>
							<input type="text" class="form-control input" id="joblocation" name="location" required/>
								</div>
							<div class="form-group">
								<label for="jobtype">Permanent Address *</label>
							<input type="text" class="form-control input" id="joblocation" name="per_add" required/>
								</div>
								<div class="form-group">
								<label for="jobtype">Preferred Location *</label>
							<input type="text" class="form-control input" id="joblocation" name="pre_location" required/>
								</div>
						
								<div class="form-group">
								<label for="jobtype">Qualification (Graduation) *</label>
							<input type="text" class="form-control input" id="joblocation" name="ug" required/>
	                        					
						</div>
						
								<div class="form-group">
								<label for="jobtype">Graduation University *</label>
							<input type="text" class="form-control input" id="joblocation" name="ug_university" required/>
	                        					
						</div>
								<div class="form-group">
								<label for="jobtype">Post Graduation</label>
							<input type="text" class="form-control input" id="joblocation" name="pg" />
	                        					
						</div>
								<div class="form-group">
								<label for="jobtype">PG University</label>
							<input type="text" class="form-control input" id="joblocation" name="pg_university" />
	                        					
						</div>
                             
								

							
							
							<div class="form-group">
								<label for="jobtype">Current CTC *</label>
							<input type="txt" class="form-control input" name="current_ctc" id="joblocation" required />
								</div>
							
							<div class="form-group">
								<label for="jobtype">Expected CTC</label>
							<input type="text" class="form-control input" id="joblocation" name="exp_ctc" required />
								</div>
							<div class="form-group">
								<label for="jobregion">Functional Area *</label>
								<select class="form-control" name="funcionalarea" required>
									<option value="R&D-seeds">R&D-seeds </option>
									<option value="R&D-chemicals">R&D-chemicals </option>
									<option  value="Registration">Registration</option>
									<option value="veterinary">veterinary</option>
									<option value="Tractor/ farm equipments">Tractor/ from equipments</option>
									<option value="Business Development">Business Development</option>
									<option value="Agri Finance">Agri Finance</option>
								        <option value="Poltry & Animal Husbandry">Poltry & Animal Feed </option>
									<option value="Warehousing and Commodity finance">Warehousing and commodity finance</option>
									<option value="Agri input-Seeds">Agri input-Seeds</option>
									<option value="Agri input-Pesticides">Agri input-Pesticides</option>
									<option value="Agri input Fertilizers">Agri input Fertilizers</option>
									<option value="Irrgation/ Drip">Irrgation/ Drip</option>
									<option value="Plantation">Plantation</option>
									<option value="Fisheries">Fisheries</option>
									<option value="procurement">Procurement</option>
									<option value="Seed Production">Seed Production</option>
									<option value="Product Development">Product Development</option>
									<option value="Education">Education</option>
									
								<option value="Other">Other</option>
								</select>
							</div>
						

						
							<div class="form-group">
								<label for="jobtype">Current Company* </label>
							<input type="text" class="form-control input" id="joblocation" placeholder=" Fresher/Company Name" name="current_company" required/>
								</div>
						<div class="form-group">
							<label for="jobtag">Key Skills *</label>
							<textarea class="form-control textarea"  name="skills"></textarea>
						</div>

						<div class="form-group">
							<label for="appemail">Experience *</label>
								<select class="form-control" name="experience" required>
									<option>Fresher</option>
									<option value="1">1 year</option>
									<option value="2">2 year</option>
									<option value="3">3 year</option>
									<option value="4">4 year</option>
							        <option value="5">5 year</option>
									<option value="6">6 year</option>
									<option value="7">7 year</option>
									<option value="8">8 year</option>
							        <option value="9">9 year</option>
									<option value="10">10 year</option>
									<option value="11">11 year</option>
									<option value="12">12 year</option>
							        <option value="13">13 year</option>
									<option value="14">14 year</option>
							        <option value="15">15 year</option>
									<option value="16">16 year</option>
									<option value="17">17 year</option>
									<option value="18">18 year</option>
									<option value="19">19 year</option>
									<option value="20">20 year</option>
									<option value="above"> above 20</option>
							
							</select>
							
						</div>
<div class="form-group">
							<label for="appemail">Upload Resume </label>
							<input type="file" class="form-control input" id="appemail" name="resume"/>
						</div>

<div class="form-group">
							<label for="appemail">Language *</label>	<br>
	 <input type="text"   placeholder="1." name="lan1" required style="width:120px;border:1px solid #dee4e5; margin-right:5px;border-radius:4px; height:32px;"/>
							 <input type="text"   name="lan2" placeholder=" 2." required style="width:120px;border:1px solid #dee4e5; margin-right:5px;border-radius:4px; height:32px;"/>
							
							 <input type="text"  name="lan3" required placeholder=" 3."style="width:120px;border:1px solid #dee4e5; margin-right:5px;border-radius:4px; height:32px;"/>
																										
																									
																										</div>
						

						
						<div class="row">
							
							
							<div class="clearfix"></div>
							
						</div>

						
						
						<div class="form-group">
							<input type="submit" class="btn btn-default btn-blue" name="register" value="Create JobSeeker Account">
						</div>
					</form>
					
					<div class="spacer-2">&nbsp;</div>
				</div>
				
				<div class="col-md-3">
					<div class="job-side-wrap">
<form action="" method="post">					
					<h5 align="center">JobSeeker ? Login Here</h5>
						<p align="center">
						<input type="text" placeholder="Email" style="width:95%;height:35px;border-radius:3px;border:solid 1px;padding:2px 10px;" name="email" required>
						</p>
						<p align="center">
						<input type="password" placeholder="*******"  style="width:95%;height:35px;border-radius:3px;border:solid 1px;padding:2px 10px;" name="password" required>
						</p>
						
						<p ><input type="submit"  value="LOG IN" style="width:80%; height:36px;background:#49C30B;border-radius:3px;border:none;color:#fff;" name="login"></p>
</form>
<p>
<a href="seeker_forgot.php" target=_blank>Forgot Password</a></p>
<?php if(isset($_POST['login']))
{
	echo"<p aligin='center' style='color:red'>$msg</p>";
}?>
						</div>

					
				</div>
			</div>
		</div>

<?php
include"footer.php";
?>

