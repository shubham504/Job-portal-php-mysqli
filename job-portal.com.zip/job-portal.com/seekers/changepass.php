<?php include "config.php";
?>
			<?php
			include"header.php";
			if(isset($_POST['savechange'])){
	$opass=md5($_POST['oldpassword']);
$npass=mysql_real_escape_string($_POST['npassword']);
$cpass=mysql_real_escape_string($_POST['cpassword']);
			
$sql=mysql_query("select password from jobseekers where email='$_SESSION[user]'");
if($row=mysql_fetch_array($sql))
{ 
$old=$row['password'];

	if($opass==$old)
	{
		if($npass==$cpass)
		{
		$sql=mysql_query("update jobseekers set password=md5('$npass') where email='$_SESSION[user]'");
	   $msge = 'Password Changes successfully';
	    echo"<div class='clearfix'></div>";

	   }
		else{
			$msge = "Password are not Same";
			 echo"<div class='clearfix'></div>";

}
	}
		else
		{
			$msge = "Old Password is not Correct";
			 echo"<div class='clearfix'></div>";

		}
		
		}
		
}
			?>
		<div class="main-page-title"><!-- start main page title -->
			<div class="container">
				<div class="post-job-title">Create your Profile</div>
				<div class="post-job-phone">Call: 0141 -3356493</div>
			</div>
		</div><!-- end main page title -->
		<div class="container">
		<div class="spacer-1">&nbsp;</div>
			<div class="row">
				<div class="col-md-9">
				<?php 
				if(isset($_POST['savechange']))
				{
					echo "<p style='color: #fff;
    text-align: center;
    padding: 5px;
    background: #F75900;
    border-radius: 9px;'>$msge</p>";
    echo"<div class='clearfix'></div>";
				}
				?>
				
					<p align="center" style="font-size:20px;">Seeker Change Password</p><hr><br>
		<form action="#" method="post" >
<label style="width:30%;">Old password</label><input type="password" name="oldpassword" class="pop_login" required >

<label style="width:30%;">New Password </label><input type="password" name="npassword" class="pop_login" required>

<label style="width:30%;">Confirm Password </label><input type="password" name="cpassword" class="pop_login" required>

<input type="submit"  value="SAVE" name="savechange" class="changepass">
	
</form>
					<div class="spacer-2">&nbsp;</div>
				</div>
								
				<div class="col-md-3">
					<div class="job-side-wrap" style="background:none">
					<img src="images/ads.jpg">
		</div>

				</div>
			</div>
		</div>

		<div id="page-content"><!-- start content -->
			<div class="content-about">
				<div id="cs"><!-- CS -->
					
			</div><!-- end content -->
		</div><!-- end page content -->
<?php
include"footer.php";
?>