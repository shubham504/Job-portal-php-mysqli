<?php
include"config.php";
echo"<script>alert('Are you Sure ? you want to Delete this post')</script>";
$id=$_GET['id'];
mysql_query("delete from job_post where id='$id'");
echo"<script>window.location='posted-jobs.php'</script>";
?>