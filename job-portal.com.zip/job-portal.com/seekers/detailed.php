<?php include "config.php";
?>
			<?php
			include"header.php";
			?>
			<?php
			
			if(isset($_POST['apply']))
			{
				$date=date("jS\ F Y");
				$job_id=$_GET['id'];
				$email=$_POST['email'];
				$applicant=$_SESSION['user'];
				$sql=mysql_query("select* from apply where job_id='$job_id' and applicant_email='$applicant'");
				
				if($row=mysql_fetch_array($sql))
				{
					$message="You have already  Applied for this job";
				}
				else
				{
				
				$sql=mysql_query("insert into apply (job_id,company_email,applicant_email,date) values('$job_id','$email','$applicant','$date')");
				$message="You have Applied for this job";	
				
				}
			}
			?>

<style>
.message{
	background: #74BB33;
    border-radius: 7px;
    border: none;
    line-height: 38px;
    padding-left: 20px;
    font-size: 18px;
    color: #fff !important;
    width: 50%;
    opacity: .80;
        margin: 12px 11%;
        
      
}
</style>

		<div class="main-page-title"><!-- start main page title -->
			<div class="container">
				<div class="post-job-title">Apply for Job Here</div>
				
			</div>
		</div>
		

	
		
		<div class="recent-job">
			<div class="container">
				<div class="row">
					<?php
					if(isset($_POST['apply']))
					{
					echo "<div class='message'>$message <a href='index.php'><img src='close.png' style='height: 35px;float:right;padding: 5px 5px;color: #000;'></a></div>";
					}
					?>
					<?php
$id=$_GET['id'];
$sql=mysql_query("select* from job_post where id='$id'");
while($row=mysql_fetch_array($sql))
{
	$logo=$row['logo']
?>	
			<div class="col-md-9" style="border:solid 1px #eee;padding:10px 10px;margin:10px 0px;background:#FAFAF9;">
	<?php
 
echo "<div class='details'><h5 style='width:70%;float:left'>$row[title]</h5><h5 style='font-size:14px'> Posted on : $row[date]</h5><p><img src='../images/location.png' height='16' title='Job Location'> -  $row[location] </p><p> <img src='../images/company.png' height='16' title='company name'> - $row[company]</p><p><img src='../images/jobtype.png' height='15' title='Job Type'> -  $row[type] </p><p><img src='../images/area.png' height='16' title='Functional area'> -  $row[category]</p><p><img src='../images/rupees.png' height='16' title='Salary per annum'> -  $row[salary]</p><br><br></div><div class='details'>
<hr>
<h5>Requirements </h5>
<p> Experience :  $row[min_experience] - $row[max_experience]  yrs</p>
<p>No of Positions :<b> $row[app_email]  </b></p><p>Qualification :  $row[qualification]</p></div>
<div class='details'><p><b>Skills</b> </p><p>&nbsp</p><p style='width:100%'>$row[skill]</p>
<p><b>Job Discription</b> </p><p>&nbsp</p><p style='width:100%'>$row[jobdiscription]</p></div><div class='details'><hr>
<h5>About Recruiter</h5>
<p style='width:100%'>$row[company_discription]</p>
<p> Visit : $row[website]</p><p>&nbsp;</p><p>&nbsp;</p>

<p><form action='' method='post'><input type='email' name='email' value='$row[email]' style='display:none'><input type='submit' value='Apply for This Job' name='apply' style='width:200px;; height:36px;background:#F75900;border-radius:3px;border:none;color:#fff;'></form></p>
				
</div>";
?>
</div>
				
<?php } ?>

<div class="col-md-3">
					

					

					<div class="job-side-wrap" style="padding:0;margin-top:5px;">
						
					<p align="center" style=" padding:0;width:100%; height:36px;background:#F75900;border-radius:3px;border:none;color:#fff;font-size:20px;">
						Administration
					<div class="admin"><li><a href="editprofile.php">Edit Profile</a></li>
					  <li><a href="#0" class="cd-popup-trigger">Change Password</a></li>
					  <li><a href="index.php">My Posted Jobs</a></li>
					  <li><a href="help.php">Help</a></li>
					  <li><a href="logout.php">Logout</a></li>
					
					</div>
					</div>
					
					
				</div>
					
					<div class="col-md-3">
						<div id="job-opening">
							<div class="job-opening-top">
								<div class="job-oppening-title">Similar Jobs </div>
								<div class="job-opening-nav">
									<a class="btn prev"></a>
									<a class="btn next"></a>
									<div class="clearfix"></div>
								</div>
							</div>
							<div class="clearfix"></div>
							<br/>
							
							<div id="job-opening-carousel" class="owl-carousel">
                          <?php
							$sql=mysql_query("select * from job_post");
							while($row=mysql_fetch_array($sql))
							{
								 $logo="../Employeerzone/logo/$row[logo]";
							?>							
								<div class="item-home">
									<div class="job-opening">
										<img src="<?php echo $logo;?>" class="img-responsive" alt="dummy-job-opening" />
										
										<div class="job-opening-content">
											<?php echo $row['title'];?>
											<p>
												<?php
                                            $dis=$row['jobdiscription'];
                                             $detail=substr($dis,0,230);												
												echo $detail;?>
											</p>
										</div>
										
										<div class="job-opening-meta clearfix">
											<div class="meta-job-location meta-block"><i class="fa fa-map-marker"></i><?php echo $row['location'];?></div>
											<div class="meta-job-type meta-block"><i class="fa fa-user"></i><a href="detailed.php?id=<?php echo $row['id']; ?>" >Apply Here</a></div>
										</div>
									</div>
								</div>
							
								
							<?php }?>	
							</div>
						</div>

						
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div><!-- end Recent Job -->
		<div class="job-status">
			<div class="container">
					<h1>Jobs Stats Updates</h1>
					

					<div class="counter clearfix">
						<div class="counter-container">
							<div class="counter-value">125</div>
							<div class="line"></div>
							<p>job posted</p>
						</div>
			
						
						<div class="counter-container">
							<div class="counter-value">50</div>
							<div class="line"></div>
							<p>possition Filled</p>
						</div>
						
						<div class="counter-container">
							<div class="counter-value">75</div>
							<div class="line"></div>
							<p>Companies</p>
						</div>
						
						<div class="counter-container">
							<div class="counter-value">85</div>
							<div class="line"></div>
							<p>Members</p>
						</div>
					</div>
				
			</div>
		</div>
	<?php
	include"footer.php";
	?>