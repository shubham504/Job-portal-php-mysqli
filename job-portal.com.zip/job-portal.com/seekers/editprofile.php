<?php include "config.php";
?>
			<?php
			include"header.php";
			?>
<?php if(isset($_POST['register']))
{
	 $mail=$_POST['email'];
	 $name=$_POST['name'];
	 
	  $ddd=$_POST['dobd'];	
	  $mmm=$_POST['dobm'];
	  $address=$_POST['per_add'];
	  $plocation=$_POST['pre_location'];
	  $ugg=$_POST['ug'];
	  $uguniv=$_POST['ug_university'];
	  $pgg=$_POST['pg'];
	  $pguniv=$_POST['pg_university'];
	  $cur_ctc=$_POST['current_ctc'];
	  $expcted=$_POST['exp_ctc'];
	 $c_com=$_POST['current_company'];
	  $lan1=$_POST['lan1'];
	 $lan2=$_POST['lan2'];
	  $lan3=$_POST['lan3'];
	
	 $yyy=$_POST['doby'];
	 $location=$_POST['location'];
	 $mobile=$_POST['mobile'];
	 $fun_area=$_POST['funcionalarea'];
	 $skills=$_POST['skills'];
	 $exp=$_POST['experience'];
	 $file_name = $_FILES['resume']['name'];
	 $encoded_image = date("d-m-y").'_'.$file_name;
	 $date=date("l jS \ F Y h:i:s A");
	
	$sql=mysql_query("update jobseekers set fullname='$name', email='$mail', mobile='$mobile', ug='$ugg', ug_university='$uguniv', pg='$pgg', pg_university='$pguniv', current_ctc='$cur_ctc',exp_ctc='$expcted', current_location='$location', per_address='$address', pre_location='$plocation', current_company='$c_com', experience='$exp', 
	keyskill='$skills', functional_area='$fun_area', lan1='$lan1', lan2='$lan2', lan3='$lan3', resume='$encoded_image',last_update='$date', dob_m='$mmm', dob_y='$yyy', dob_d='$ddd' where email='$_SESSION[user]'");
move_uploaded_file($_FILES['resume']['tmp_name'],"resumes/".$encoded_image);
	 
	$msg1="Your Profile Updated Successfully";
	}

?>

		<div class="main-page-title"><!-- start main page title -->
			<div class="container">
				<div class="post-job-title">Create your Profile</div>
				<div class="post-job-phone">Call: 0141 -3356493</div>
			</div>
		</div><!-- end main page title -->
		<div class="container">
		<div class="spacer-1">&nbsp;</div>
			<div class="row">
				<div class="col-md-9">
				<?php 
				if(isset($_POST['register']))
				{
					echo "<p style='color:red'>$msg1</p>";
				}
				?>
				
					<form role="form" class="post-job-form" method="post" action="" enctype="multipart/form-data">
<?php $sql=mysql_query("select * from jobseekers where email='$_SESSION[user]'");

if($row=mysql_fetch_array($sql))
{
	?>
				<div class="form-group">
							<label for="email">Your Email *</label>
							<input type="email" class="form-control input" id="email" name="email" value="<?php echo $row['email'];?>" readonly required/>
						</div>
						<div class="form-group">
							<label for="jobtitle">Full Name *</label>
							<input type="text" class="form-control input" id="jobtitle" name="name" value="<?php echo $row['fullname'];?>" required/>
						</div>

                          <div class="form-group">
								<label for="jobtype">Mobile No *</label>
							<input type="text" class="form-control input" id="joblocation" name="mobile" value="<?php echo $row['mobile'];?>" required />
								</div>
						<div class="form-group">
								<label for="jobtype">Date of Birth *</label><br>
							<input type="text"   placeholder="  DD" name="dobd" value="<?php echo $row['dob_d'];?>" required style="width:70px;border:1px solid #dee4e5; margin-right:10px;border-radius:4px; height:32px;"/>
							<input type="text"   name="dobm" placeholder=" MM" required value="<?php echo $row['dob_m'];?>" style="width:70px;border:1px solid #dee4e5; margin-right:10px;border-radius:4px; height:32px;"/>
							
							<input type="text"  name="doby" required placeholder=" YYYY" value="<?php echo $row['dob_y'];?>" style="width:100px;border:1px solid #dee4e5; margin-right:10px;border-radius:4px; height:32px;"/>
								</div>
						
							<div class="form-group">
								<label for="jobtype">Current Location *</label>
							<input type="text" class="form-control input" id="joblocation" name="location" value="<?php echo $row['current_location'];?>" required/>
								</div>
							<div class="form-group">
								<label for="jobtype">Permanent Address *</label>
							<input type="text" class="form-control input" id="joblocation" name="per_add" value="<?php echo $row['per_address'];?>" required/>
								</div>
								<div class="form-group">
								<label for="jobtype">Preferred Location *</label>
							<input type="text" class="form-control input" id="joblocation" name="pre_location" value="<?php echo $row['pre_location'];?>" required/>
								</div>
						
								<div class="form-group">
								<label for="jobtype">Qualification (Graduation) *</label>
							<input type="text" class="form-control input" id="joblocation" name="ug" value="<?php echo $row['ug'];?>" required/>
	                        					
						</div>
						
								<div class="form-group">
								<label for="jobtype">Graduation University *</label>
							<input type="text" class="form-control input" id="joblocation" value="<?php echo $row['ug_university'];?>" name="ug_university" required/>
	                        					
						</div>
								<div class="form-group">
								<label for="jobtype">Post Graduation</label>
							<input type="text" class="form-control input" id="joblocation" value="<?php echo $row['pg'];?>" name="pg" />
	                        					
						</div>
								<div class="form-group">
								<label for="jobtype">PG University</label>
							<input type="text" class="form-control input" id="joblocation" value="<?php echo $row['pg_university'];?>" name="pg_university" />
	                        					
						</div>
                             
								

							
							
							<div class="form-group">
								<label for="jobtype">Current CTC *</label>
							<input type="text" class="form-control input" id="joblocation"  value="<?php echo $row['current_ctc'];?>" name="current_ctc" required />
								</div>
							
							<div class="form-group">
								<label for="jobtype">Expected CTC</label>
							<input type="text" class="form-control input" id="joblocation" name="exp_ctc" value="<?php echo $row['exp_ctc'];?>" required />
								</div>
							<div class="form-group">
								<label for="jobregion">Functional Area *</label>
								<select class="form-control" name="funcionalarea" required>
									<option   selected><?php echo $row['functional_area'];?></option>
									<option value="R&D-seeds">R&D-seeds </option>
									<option value="R&D-chemicals">R&D-chemicals </option>
									<option  value="Registration">Registration</option>
									<option value="veterinary">veterinary</option>
									<option value="Tractor/ farm equipments">Tractor/ from equipments</option>
									<option value="Business Development">Business Development</option>
									<option value="Agri Finance">Agri Finance</option>
								        <option value="Poltry & Animal Husbandry">Poltry & Animal Feed </option>
									<option value="Warehousing and Commodity finance">Warehousing and commodity finance</option>
									<option value="Agri input-Seeds">Agri input-Seeds</option>
									<option value="Agri input-Pesticides">Agri input-Pesticides</option>
									<option value="Agri input Fertilizers">Agri input Fertilizers</option>
									<option value="Irrgation/ Drip">Irrgation/ Drip</option>
									<option value="Plantation">Plantation</option>
									<option value="Fisheries">Fisheries</option>
									<option value="procurement">Procurement</option>
									<option value="Seed Production">Seed Production</option>
									<option value="Product Development">Product Development</option>
									<option value="Education">Education</option>
									
								<option value="Other">Other</option>
								</select>
							</div>
						

						
							<div class="form-group">
								<label for="jobtype">Current Company* </label>
							<input type="text" class="form-control input" id="joblocation" value="<?php echo $row['current_company'];?>" placeholder=" Fresher/Company Name" name="current_company" required/>
								</div>
						<div class="form-group">
							<label for="jobtag">Key Skills *</label>
							<textarea class="form-control textarea"  name="skills"><?php echo $row['keyskill'];?></textarea>
						</div>

						<div class="form-group">
							<label for="appemail">Experience *</label>
								<select class="form-control" name="experience" required>
									<option value="<?php echo $row['experience'];?>" ><?php echo $row['experience'] ; ?></option>
									<option>Fresher</option>
									<option value="1">1 year</option>
									<option value="2">2 year</option>
									<option value="3">3 year</option>
									<option value="4">4 year</option>
							        <option value="5">5 year</option>
									<option value="6">6 year</option>
									<option value="7">7 year</option>
									<option value="8">8 year</option>
							        <option value="9">9 year</option>
									<option value="10">10 year</option>
									<option value="11">11 year</option>
									<option value="12">12 year</option>
							        <option value="13">13 year</option>
									<option value="14">14 year</option>
							        <option value="15">15 year</option>
									<option value="16">16 year</option>
									<option value="17">17 year</option>
									<option value="18">18 year</option>
									<option value="19">19 year</option>
									<option value="20">20 year</option>
									<option value="above"> above 20</option>
							
							</select>
							
						</div>
<div class="form-group">
							<label for="appemail">Upload Resume </label>
							<input type="file" class="form-control input" id="appemail" name="resume"/>
						</div>

<div class="form-group">
							<label for="appemail">Language *</label>	<br>
	 <input type="text"   placeholder="1." name="lan1" value="<?php echo $row['lan1'];?>" required style="width:120px;border:1px solid #dee4e5; margin-right:5px;border-radius:4px; height:32px;"/>
							 <input type="text"   value="<?php echo $row['lan2'];?>" name="lan2" placeholder=" 2." required style="width:120px;border:1px solid #dee4e5; margin-right:5px;border-radius:4px; height:32px;"/>
							
							 <input type="text"  value="<?php echo $row['lan3'];?>" name="lan3" required placeholder=" 3."style="width:120px;border:1px solid #dee4e5; margin-right:5px;border-radius:4px; height:32px;"/>
																										
																									
																										</div>
						

						
						<div class="row">
							
							
							<div class="clearfix"></div>
							
						</div>

						
						
						<div class="form-group">
							<input type="submit" class="btn btn-default btn-blue" name="register" value="Edit Profile ">
						</div>
<?php } ?>
					</form>
					
					<div class="spacer-2">&nbsp;</div>
				</div>
								
				<div class="col-md-3">
					<div class="job-side-wrap" style="background:none">
					<img src="images/ads.jpg">
		</div>

				</div>
			</div>
		</div>

		<div id="page-content"><!-- start content -->
			<div class="content-about">
				<div id="cs"><!-- CS -->
					
			</div><!-- end content -->
		</div><!-- end page content -->
<?php
include"footer.php";
?>