	<div id="footer"><!-- Footer -->
			<div class="container"><!-- Container -->
				

				<div class="footer-credits"><!-- Footer credits -->
					2015 © All Right Reserved. Design & Develop by <a href="http://www.inventiveinfosys.com">Inventive Infosys</a>
				</div><!-- Footer credits -->
				
			</div><!-- Container -->
		</div><!-- Footer -->
	</div><!-- end main wrapper -->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script type="text/javascript" src="js/main.js"></script>
    <script src="js/bootstrap.min.js"></script>

	<!-- Tabs -->
	<script src="js/jquery.easytabs.min.js" type="text/javascript"></script>
	<script src="js/modernizr.custom.49511.js"></script>
	<!-- Tabs -->

	<!-- Owl Carousel -->
	<script src="js/owl.carousel.js"></script>
	<!-- Owl Carousel -->

	<!-- Form Slider -->
	<script type="text/javascript" src="js/jquery.numberformatter-1.2.3.js"></script>
	<script type="text/javascript" src="js/jshashtable-2.1_src.js"></script>
	<script type="text/javascript" src="js/tmpl.js"></script>
	<script type="text/javascript" src="js/jquery.dependClass-0.1.js"></script>
	<script type="text/javascript" src="js/draggable-0.1.js"></script>
	<script type="text/javascript" src="js/jquery.slider.js"></script>
	<!-- Form Slider -->
	
	<!-- Map -->
	<script src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
	<!-- Map -->

	<script src="js/job-board.js"></script>

  </body>
</html>