<?php

$user = $_SESSION['user'];
$user_pass = $_SESSION['user_pass'];
if(empty($user)||($user_pass))
{
	echo"<script>window.location='../seeker_registration.php'</script>";

}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Job Board</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Nunito:300,400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,300,500,600,700' rel='stylesheet' type='text/css'>
	<link href='../css/font-awesome.css' rel="stylesheet" type="text/css">
	<link href="../css/owl.carousel.css" rel="stylesheet">
    <link href="../css/owl.theme.css" rel="stylesheet">
	<link href="../css/owl.transitions.css" rel="stylesheet">
	<link rel="stylesheet" href="../css/jslider.css" type="text/css">
	<link rel="stylesheet" href="../css/jslider.round.css" type="text/css">
	<link rel="stylesheet" href="css/changepas.css" type="text/css">
	</head>

  <body>
	<div id="wrapper"><!-- start main wrapper -->
		<div id="header"><!-- start main header -->
			<div class="top-line">&nbsp;</div>
			<div class="top"><!-- top -->
				<div class="container">
					<div class="media-top-right">
						
						<ul class="media-top-2 clearfix">
<?php
$sql=mysql_query("select * from jobseekers where email='$_SESSION[user]'");
if($row=mysql_fetch_array($sql))
{
?>						
<li style="color:#49C30B"><u><b><?php echo $row['fullname'];}?></u></b> <a href="logout.php"  class="" >Logout </a></li>
						
						</ul>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>

			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<a href="index.php" title="Job Board" rel="home">
							<img class="main-logo" src="images/logo.png" alt="job board" />
						</a>
					</div>
					<div class="col-md-8 main-nav">
						<a id="touch-menu" class="mobile-menu" href="#"><i class="fa fa-bars fa-2x"></i></a>
						<nav>
							<ul class="menu">
								<li><a href="index.php">Jobs</a>
									
								</li>
								
								<li><a  href="editprofile.php">POST RESUME</a></li>
								<li><a  href="posted-jobs.php">COMPANIES</a></li>
								
								<li><a  href="#">My Profile</a>
								<ul class="sub-menu">
										<li><a href="editprofile.php">Edit Profile</a></li>
										<li><a href="changepass.php">Change Password</a></li>
										
										<li><a href="#">Help</a></li>
										<li><a href="logout.php">Logout </a></li>
										</ul></li>
								
															
							</ul>
						</nav>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>

	
	