<?php
include "config.php";
?>
			<?php
			include"header.php";
			?>
<?php

if(isset($_POST['post']))
{
	
	$mail=$_POST['email'];
	
	$title=$_POST['title'];
	
	$location=$_POST['location'];
	
	$type=$_POST['type'];
	
	$category=$_POST['category'];
	$discription=$_POST['discription'];
	
	$appemail=$_POST['app_mail'];
	$cname=$_POST['company'];
	$website=$_POST['website'];
	$company_dis=$_POST['company_discription'];
	$file_name = $_FILES['logo']['name'];
	$user_email=$_SESSION['user'];
	$encoded_image =  base64_encode($file_name);
	$date=date("l jS \ F Y h:i:s A");
	$sql=mysql_query("insert into job_post (email,title,location,type,category,jobdiscription,app_email,company,website,company_discription, logo,user_email,date) VALUES
	('$mail','$title','$location','$type','$category','$discription','$appemail','$cname','$website','$company_dis','$encoded_image','$user_email','$date')");
move_uploaded_file($_FILES['logo']['tmp_name'],"logo/".$encoded_image);
	 
	$msg1="Your Job Posted Successfully";
	
}


?>
		<div class="main-page-title"><!-- start main page title -->
			<div class="container">
				<div class="post-job-title">Post a Job</div>
				<div class="post-job-phone">Call: 1 800 000 500</div>
			</div>
		</div><!-- end main page title -->
		<div class="container">
		<div class="spacer-1">&nbsp;</div>
			<div class="row">
<?php			
if(isset($_POST['post']))
{
			echo"<p>$msg1</p>";
}
			?>
				<div class="col-md-8">
					<form role="form" class="post-job-form" method="post" enctype="multipart/form-data">
						<div class="form-group">
							<label for="email">Your Email</label>
							<input type="email" class="form-control input" id="email" name="email" />
						</div>
						<div class="form-group">
							<label for="jobtitle">Job Title</label>
							<input type="text" class="form-control input" id="jobtitle" name="title" />
						</div>

						<div class="form-group">
							<label for="joblocation">Job Location </label>
							<input type="text" class="form-control input" id="joblocation" name="location"/>
							
						</div>

						
						
							<div class="form-group">
								<label  for="jobtag">Job Type</label>
								<select class="form-control" name="type">
									<option>Blank 1</option>
									<option>Blank 2</option>
									<option>Blank 3</option>
									<option>Blank 4</option>
									<option>Blank 5</option>
								</select>
							</div>
						
							<div class="form-group">
								<label  for="jobtag">Job Category</label>
								<select class="form-control" name="category">
									<option>Blank 1</option>
									<option>Blank 2</option>
									<option>Blank 3</option>
									<option>Blank 4</option>
									<option>Blank 5</option>
								</select>
							</div>
						

						
						<div class="form-group">
							<label for="jobtag">Description</label>
							<textarea class="form-control textarea" name="discription"></textarea>
						</div>

						<div class="form-group">
							<label for="appemail">Application Email </label>
							<input type="text" class="form-control input" id="appemail" name="app_mail"/>
						</div>


						<h3>Company Details</h3>
							<div class="form-group">
								<label for="companyname">Company Name</label>
								<input type="text" class="form-control input" id="companyname" name="company" />
							</div>

							<div class="form-group">
								<label for="tagline">Website</label>
								<input type="text" class="form-control input" id="tagline" name="website" />
							</div>
						
						<div class="form-group">
							<label for="jobtag">Description</label>
							<textarea class="form-control textarea" name="company_discription"></textarea>
						</div>
						<div class="row">
							
							
							<div class="clearfix"></div>
							
						</div>

						
						<div class="form-group">
							<label for="logo">Logo <span>(Optional)</span> <small>Max. file size: 8 MB.</small></label>
							
								<input type="file" id="logo" name="logo" >
							
						</div>
						<div class="form-group">
							<input type="submit" name="post" value="POST JOB" class="btn btn-default btn-green">
						</div>
					</form>
					<div class="spacer-2">&nbsp;</div>
				</div>
				
				<div class="col-md-4">
					

					

					<div class="job-side-wrap" >
						
					<p align="center" style="width:100%; height:36px;background:#1abc9c;border-radius:3px;border:none;color:#fff;font-size:20px">
						Administration
					<ul><li><a href="Profile.php">Company Profile</a></li>
					  <li><a href="Profile.php">Company Profile</a></li>
					  <li><a href="Profile.php">Company Profile</a></li>
					  <li><a href="Profile.php">Company Profile</a></li>
					</ul>
					</div>
				</div>
			</div>
		</div>

	
<?php
include"footer.php";
?>