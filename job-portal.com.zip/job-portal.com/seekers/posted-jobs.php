<?php
include "config.php";
?>
			<?php
			include"header.php";
			?>	<div class="main-page-title"><!-- start main page title -->
			<div class="container">
				<div class="post-job-title">Our Recuiter </div>
				</div>
		</div><!-- end main page title -->
		<div class="container">
		<div class="spacer-1">&nbsp;</div>

</div>
				
<h1>Comming Soon</h1>
				
<h1>Welcome to JobsinAgri.com</h1>

				</div>
		</div>

	
<?php
include"footer.php";
?>