<?php include"config.php";
			include"header.php";
			
			
			?>
			

		
	
		<div class="job-finder">
			<div class="container">
				<h4>Our Services</h4>
				
					<div class="col-md-12 ">
<?php $sql=mysql_query("select* from services");
while($row=mysql_fetch_array($sql))
{
echo "<h5>$row[title]</h5>";

echo "<p>$row[content]</p>";	
}
?>				
					</div>
					
					
				
			</div>
		</div>
		
	<?php
	include"footer.php";
	?>