<?php
include("config.php");
$data = array();
$uname=mysql_real_escape_string($_POST['username']);
$pass=mysql_real_escape_string($_POST['password']);
$sql=mysql_query("select * from jobseekers where email='$uname' and password=md5('$pass')");
	if($row=mysql_fetch_array($sql))
	{
		$_SESSION['user']=$uname;
		$_SESSION['user_password']=$pass;
		$data['success'] = 'Login successfully';
	}
	else{
	$data['error'] = "Invalid Email or Password";
	}
	echo json_encode($data);
	exit();


?>